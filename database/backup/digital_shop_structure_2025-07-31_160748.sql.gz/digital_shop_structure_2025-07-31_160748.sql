-- MySQL Dump
-- Host: localhost via TCP/IP
-- Generation Time: 2025-07-31 16:07:48
-- PHP Version: 8.2.12

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = '+00:00';

--
-- Table structure for table `aboutus`
--
DROP TABLE IF EXISTS `aboutus`;
CREATE TABLE `aboutus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `established_date` date DEFAULT NULL,
  `mission` text DEFAULT NULL,
  `vision` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `articles`
--
DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `author_id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `category` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `category` (`category`),
  CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  CONSTRAINT `articles_ibfk_2` FOREIGN KEY (`category`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `categories`
--
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `consultationmessages`
--
DROP TABLE IF EXISTS `consultationmessages`;
CREATE TABLE `consultationmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consultation_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `consultation_id` (`consultation_id`),
  KEY `sender_id` (`sender_id`),
  CONSTRAINT `consultationmessages_ibfk_1` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `consultationmessages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `consultations`
--
DROP TABLE IF EXISTS `consultations`;
CREATE TABLE `consultations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `advisor_id` int(11) NOT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `consultation_date` datetime DEFAULT NULL,
  `status` enum('pending','confirmed','completed','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `advisor_id` (`advisor_id`),
  CONSTRAINT `consultations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `consultations_ibfk_2` FOREIGN KEY (`advisor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `contactmessages`
--
DROP TABLE IF EXISTS `contactmessages`;
CREATE TABLE `contactmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `discounts`
--
DROP TABLE IF EXISTS `discounts`;
CREATE TABLE `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `discount_type` enum('percentage','fixed') NOT NULL,
  `discount_value` decimal(12,2) NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `discounts_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `faqs`
--
DROP TABLE IF EXISTS `faqs`;
CREATE TABLE `faqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `category` varchar(50) NOT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `favorites`
--
DROP TABLE IF EXISTS `favorites`;
CREATE TABLE `favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`product_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `notifications`
--
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('new_user','new_order','new_message','new_review','new_consultation','other') NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `is_dismissed` tinyint(1) DEFAULT 0,
  `related_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=527 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `orderdetails`
--
DROP TABLE IF EXISTS `orderdetails`;
CREATE TABLE `orderdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` decimal(12,0) NOT NULL,
  `subtotal` decimal(12,0) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `orderdetails_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `orderdetails_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=395 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `orders`
--
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `total_price` decimal(12,0) NOT NULL,
  `status` enum('pending','processing','shipped','completed','cancelled') DEFAULT 'pending',
  `payment_status` enum('paid','unpaid') DEFAULT 'unpaid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `payments`
--
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(12,0) NOT NULL,
  `payment_method` enum('online','cash_on_delivery') DEFAULT 'online',
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('successful','failed') DEFAULT 'successful',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `productattributes`
--
DROP TABLE IF EXISTS `productattributes`;
CREATE TABLE `productattributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `attribute_name` varchar(255) NOT NULL,
  `attribute_value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `productattributes_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=360 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `productcomparison`
--
DROP TABLE IF EXISTS `productcomparison`;
CREATE TABLE `productcomparison` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `productcomparison_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `productcomparison_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `productimages`
--
DROP TABLE IF EXISTS `productimages`;
CREATE TABLE `productimages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `productimages_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `products`
--
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `description` text DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `image_url` varchar(255) DEFAULT 'image/default-Product.jpg',
  `minimum_stock` int(11) DEFAULT 5,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `productviews`
--
DROP TABLE IF EXISTS `productviews`;
CREATE TABLE `productviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `view_date` date NOT NULL,
  `view_count` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_daily_view` (`product_id`,`ip_address`,`view_date`),
  KEY `product_id` (`product_id`),
  KEY `ip_address` (`ip_address`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2536 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `reviews`
--
DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `reviews` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `shopsettings`
--
DROP TABLE IF EXISTS `shopsettings`;
CREATE TABLE `shopsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(255) NOT NULL,
  `shop_description` text DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `instagram` varchar(100) DEFAULT NULL,
  `telegram` varchar(100) DEFAULT NULL,
  `whatsapp` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `working_hours` varchar(100) DEFAULT NULL,
  `youtube` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `button_color` varchar(20) DEFAULT '#007bff',
  `font_family` varchar(100) DEFAULT 'Arial, sans-serif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `shopsliders`
--
DROP TABLE IF EXISTS `shopsliders`;
CREATE TABLE `shopsliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_url` varchar(255) NOT NULL,
  `caption` text DEFAULT NULL,
  `button_text` varchar(50) DEFAULT NULL,
  `button_link` varchar(255) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `teammembers`
--
DROP TABLE IF EXISTS `teammembers`;
CREATE TABLE `teammembers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `about_us_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `bio` text DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `instagram_link` varchar(255) DEFAULT NULL,
  `telegram_link` varchar(255) DEFAULT NULL,
  `linkedin_link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `about_us_id` (`about_us_id`),
  CONSTRAINT `teammembers_ibfk_1` FOREIGN KEY (`about_us_id`) REFERENCES `aboutus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `users`
--
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `avatar` varchar(255) DEFAULT 'static/img/default-avatar.svg',
  `role` enum('admin','user') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_activity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping triggers
--
DROP TRIGGER IF EXISTS `after_consultation_message_insert`;
DELIMITER //
CREATE TRIGGER `after_consultation_message_insert` AFTER INSERT ON `consultationmessages` FOR EACH ROW
BEGIN
    DECLARE consultation_topic VARCHAR(255);
    DECLARE receiver_id INT;
    
    SELECT topic INTO consultation_topic FROM Consultations WHERE id = NEW.consultation_id;
    
    -- تعیین دریافت کننده پیام
    IF NEW.sender_id = (SELECT user_id FROM Consultations WHERE id = NEW.consultation_id) THEN
        SET receiver_id = (SELECT advisor_id FROM Consultations WHERE id = NEW.consultation_id);
    ELSE
        SET receiver_id = (SELECT user_id FROM Consultations WHERE id = NEW.consultation_id);
    END IF;
    
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('new_message', 'پیام جدید در مشاوره', CONCAT('پیام جدید در مشاوره با موضوع ', consultation_topic), NEW.consultation_id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_consultation_insert`;
DELIMITER //
CREATE TRIGGER `after_consultation_insert` AFTER INSERT ON `consultations` FOR EACH ROW
BEGIN
    DECLARE user_name VARCHAR(255);
    DECLARE advisor_name VARCHAR(255);
    
    SELECT name INTO user_name FROM Users WHERE id = NEW.user_id;
    SELECT name INTO advisor_name FROM Users WHERE id = NEW.advisor_id;
    
    -- نوتیفیکیشن برای ادمین
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('new_consultation', 'درخواست مشاوره جدید', 
            CONCAT('درخواست مشاوره جدید از کاربر ', user_name, ' با موضوع ', NEW.topic), 
            NEW.id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_contact_message_insert`;
DELIMITER //
CREATE TRIGGER `after_contact_message_insert` AFTER INSERT ON `contactmessages` FOR EACH ROW
BEGIN
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('other', 'پیام جدید از تماس با ما', CONCAT('پیام جدید از ', NEW.name, ' با موضوع ', NEW.message), NEW.id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_discount_insert`;
DELIMITER //
CREATE TRIGGER `after_discount_insert` AFTER INSERT ON `discounts` FOR EACH ROW
BEGIN
    DECLARE product_name VARCHAR(255);
    
    SELECT name INTO product_name FROM Products WHERE id = NEW.product_id;
    
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('other', 'تخفیف جدید', CONCAT('تخفیف جدید برای محصول ', product_name, ' ثبت شد'), NEW.product_id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `before_discount_end_date_update`;
DELIMITER //
CREATE TRIGGER `before_discount_end_date_update` BEFORE UPDATE ON `discounts` FOR EACH ROW
BEGIN
    DECLARE product_name VARCHAR(255);
    
    IF NEW.end_date < DATE_ADD(NOW(), INTERVAL 3 DAY) AND OLD.end_date >= DATE_ADD(NOW(), INTERVAL 3 DAY) THEN
        SELECT name INTO product_name FROM Products WHERE id = NEW.product_id;
        
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('other', 'تخفیف در حال اتمام', 
                CONCAT('تخفیف محصول ', product_name, ' تا ', NEW.end_date, ' اعتبار دارد'), 
                NEW.product_id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_order_insert`;
DELIMITER //
CREATE TRIGGER `after_order_insert` AFTER INSERT ON `orders` FOR EACH ROW
BEGIN
    DECLARE user_name VARCHAR(255);
    
    SELECT name INTO user_name FROM Users WHERE id = NEW.user_id;
    
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('new_order', 'سفارش جدید', CONCAT('سفارش جدید از کاربر ', user_name, ' در سبد خرید' ' ثبت شد'), NEW.id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_order_status_update`;
DELIMITER //
CREATE TRIGGER `after_order_status_update` AFTER UPDATE ON `orders` FOR EACH ROW
BEGIN
    DECLARE user_name VARCHAR(255);
    
    IF OLD.status <> NEW.status THEN
        SELECT name INTO user_name FROM Users WHERE id = NEW.user_id;

        -- نوتیفیکیشن برای ادمین
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('order_status_change', 'تغییر وضعیت سفارش', 
                CONCAT('وضعیت سفارش شماره ', NEW.id, ' از ', OLD.status, ' به ', NEW.status, ' تغییر کرد'), 
                NEW.id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_payment_success`;
DELIMITER //
CREATE TRIGGER `after_payment_success` AFTER INSERT ON `payments` FOR EACH ROW
BEGIN
    DECLARE user_name VARCHAR(255);
    DECLARE order_total DECIMAL(12, 0);

    IF NEW.status = 'successful' THEN
        SELECT name INTO user_name FROM Users WHERE id = NEW.user_id;
        SELECT total_price INTO order_total FROM Orders WHERE id = NEW.order_id;

        -- نوتیفیکیشن برای ادمین
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('new_order', 'پرداخت موفق', CONCAT('پرداخت سفارش شماره ', NEW.order_id, ' توسط کاربر ', user_name, ' با مبلغ ', NEW.amount, ' انجام شد'), NEW.order_id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_product_insert`;
DELIMITER //
CREATE TRIGGER `after_product_insert` AFTER INSERT ON `products` FOR EACH ROW
BEGIN
    DECLARE category_name VARCHAR(255);
    
    SELECT name INTO category_name FROM Categories WHERE id = NEW.category_id;
    
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('other', 'محصول جدید', CONCAT('محصول جدید با نام ', NEW.name, ' در دسته‌بندی ', category_name, ' اضافه شد'), NEW.id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `before_product_stock_update`;
DELIMITER //
CREATE TRIGGER `before_product_stock_update` BEFORE UPDATE ON `products` FOR EACH ROW
BEGIN
    IF NEW.stock < 5 AND NEW.stock > 0 AND OLD.stock >= 5 THEN
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('other', 'موجودی کم محصول', CONCAT('موجودی محصول ', NEW.name, ' در حال اتمام است. موجودی فعلی: ', NEW.stock), NEW.id, FALSE, FALSE);
    ELSEIF NEW.stock = 0 AND OLD.stock > 0 THEN
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('other', 'اتمام موجودی محصول', CONCAT('موجودی محصول ', NEW.name, ' به پایان رسید'), NEW.id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_product_view_insert`;
DELIMITER //
CREATE TRIGGER `after_product_view_insert` AFTER INSERT ON `productviews` FOR EACH ROW
BEGIN
    DECLARE total_views INT;
    DECLARE product_name VARCHAR(255);
    
    SELECT SUM(view_count) INTO total_views FROM ProductViews WHERE product_id = NEW.product_id;
    
    -- اگر بازدیدها از 1000 گذشت
    IF total_views % 1000 = 0 AND total_views > 0 THEN        
        SELECT name INTO product_name FROM Products WHERE id = NEW.product_id;
        
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('other', 'رکورد بازدید محصول', 
                CONCAT('محصول ', product_name, ' به ', total_views, ' بازدید رسید'), 
                NEW.product_id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_user_insert`;
DELIMITER //
CREATE TRIGGER `after_user_insert` AFTER INSERT ON `users` FOR EACH ROW
BEGIN
    IF NEW.role = 'user' THEN
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('new_user', 'کاربر جدید', CONCAT('کاربر جدید با نام ', NEW.name, ' ثبت نام کرد'), NEW.id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_user_update`;
DELIMITER //
CREATE TRIGGER `after_user_update` AFTER UPDATE ON `users` FOR EACH ROW
BEGIN
    IF OLD.avatar <> NEW.avatar THEN
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('other', 'تغییر تصویر پروفایل', CONCAT('کاربر ', NEW.name, ' تصویر پروفایل خود را تغییر داد'), NEW.id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

--
-- Dumping routines
--
-- No procedures found

-- No functions found

--
-- Dumping events
--
-- No events found

SET FOREIGN_KEY_CHECKS=1;
COMMIT;
