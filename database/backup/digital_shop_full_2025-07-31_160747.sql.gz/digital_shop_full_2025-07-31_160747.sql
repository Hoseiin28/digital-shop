-- MySQL Dump
-- Host: localhost via TCP/IP
-- Generation Time: 2025-07-31 16:07:47
-- PHP Version: 8.2.12

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = '+00:00';

--
-- Table structure for table `aboutus`
--
DROP TABLE IF EXISTS `aboutus`;
CREATE TABLE `aboutus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `established_date` date DEFAULT NULL,
  `mission` text DEFAULT NULL,
  `vision` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `aboutus`
--
INSERT INTO `aboutus` VALUES ('1', 'شرکت ما در سال 1390 با هدف ارائه خدمات با کیفیت و نوآورانه در زمینه فناوری اطلاعات تأسیس شد. ما به عنوان یک پیشگام در صنعت فناوری، همواره تلاش کرده‌ایم تا راهکارهای بهینه و کارآمدی را برای مشتریان خود فراهم کنیم. با تیمی متخصص و متعهد، در پی ارتقاء سطح دانش و مهارت‌های خود هستیم و به دنبال ایجاد ارزش افزوده برای مشتریان و جامعه هستیم.', '2011-12-31', 'ماموریت ما ارائه خدمات با کیفیت و ایجاد تجربه‌ای مثبت برای مشتریان است. ما به دنبال نوآوری در محصولات و خدمات خود هستیم و همواره در تلاشیم تا نیازهای متنوع مشتریان خود را شناسایی و برآورده کنیم. ما به اصول اخلاقی و حرفه‌ای پایبندیم و از هر فرصتی برای بهبود مستمر استفاده می‌کنیم.', 'چشم‌انداز ما تبدیل شدن به یک رهبر جهانی در ارائه خدمات فناوری اطلاعات است. ما با تکیه بر نوآوری و کیفیت، به دنبال ایجاد یک برند معتبر و قابل اعتماد در سطح بین‌المللی هستیم. ما باور داریم که با همکاری و همیاری تیمی، می‌توانیم به اهداف بلندمدت خود دست یابیم و نقشی مؤثر در توسعه صنعت فناوری ایفا کنیم.', '2025-07-31 13:15:27', '2025-07-31 13:21:12');

--
-- Table structure for table `articles`
--
DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `author_id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `category` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `category` (`category`),
  CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  CONSTRAINT `articles_ibfk_2` FOREIGN KEY (`category`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `articles`
--
INSERT INTO `articles` VALUES ('1', 'رونمایی از جدیدترین پردازنده‌های اینتل در سال 2024', 'شرکت اینتل در نمایشگاه CES 2024 از نسل جدید پردازنده&zwnj;های Core Ultra خود رونمایی کرد. این پردازنده&zwnj;ها که بر پایه معماری Meteor Lake ساخته شده&zwnj;اند، بهبود 20 درصدی در عملکرد و 30 درصدی در بهره&zwnj;وری انرژی ارائه می&zwnj;دهند. مهمترین ویژگی این پردازنده&zwnj;ها، واحد پردازش عصبی اختصاصی برای تسریع کارهای هوش مصنوعی است که می&zwnj;تواند تحول بزرگی در لپتاپ&zwnj;های نسل آینده ایجاد کند.', '1', '../image/article-uploads/686c0d415861a.jpeg', 'active', '11', '2024-01-15 10:00:00');
INSERT INTO `articles` VALUES ('2', 'شیائومی از گوشی جدید سری ردمی نوت 13 رونمایی کرد', 'شرکت شیائومی امروز از گوشی&zwnj;های جدید سری ردمی نوت 13 شامل مدل&zwnj;های استاندارد، پرو و پرو پلاس رونمایی کرد. این گوشی&zwnj;ها با صفحه نمایش AMOLED 120Hz، پردازنده Snapdragon 7s Gen 2 و دوربین اصلی 200 مگاپیکسلی عرضه شده&zwnj;اند. مدل پرو پلاس این سری با باتری 5000mAh و شارژ 120 واتی می&zwnj;تواند در تنها 19 دقیقه به طور کامل شارژ شود..', '1', '../image/article-uploads/686c0cf093766.jpeg', 'active', '11', '2024-02-20 14:30:00');
INSERT INTO `articles` VALUES ('3', 'اپل از Vision Pro رسماً رونمایی کرد', 'سرانجام پس از ماه&zwnj;ها انتظار، اپل از هدست واقعیت ترکیبی Vision Pro خود با قیمت 3499 دلار رونمایی کرد. این هدست که ترکیبی از واقعیت مجازی و افزوده است، با تراشه M2 و پردازنده اختصاصی R1 عرضه شده و می&zwnj;تواند با دقت بالا محیط اطراف را ردیابی کند. عرضه این محصول از فوریه 2024 در آمریکا آغاز خواهد شد.', '1', '../image/article-uploads/686c0d4a63110.jpeg', 'active', '11', '2024-01-10 09:15:00');
INSERT INTO `articles` VALUES ('4', 'چگونه بهترین لپتاپ گیمینگ را برای بودجه‌های مختلف انتخاب کنیم؟', 'انتخاب لپتاپ گیمینگ مناسب به عوامل مختلفی از جمله بودجه، نوع بازی&zwnj;ها و قابلیت حمل بستگی دارد. در بودجه زیر 30 میلیون، مدل&zwnj;هایی مانند ایسر Nitro 5 یا لنوو Legion 5 انتخاب&zwnj;های مناسبی هستند. برای بودجه 30-50 میلیون، می&zwnj;توان به ایسوس ROG Zephyrus یا ام&zwnj;اس&zwnj;آی Katana فکر کرد. در رده بالای 50 میلیون نیز لپتاپ&zwnj;هایی مانند ایسوس ROG Strix Scar یا رزر بلید 15 عملکردی مشابه سیستم&zwnj;های دسکتاپ ارائه می&zwnj;دهند.', '2', '../image/article-uploads/686c0d78b1641.jpeg', 'active', '12', '2023-12-05 11:45:00');
INSERT INTO `articles` VALUES ('5', 'مقایسه گوشی‌های پرچمدار 2024: کدام یک ارزش خرید دارد؟', 'در این مقاله به مقایسه فنی گوشی&zwnj;های پرچمدار سال 2024 شامل گلکسی S24 Ultra، آیفون 15 Pro Max، شیائومی 14 Ultra و وان پلاس 12 پرداخته&zwnj;ایم. از نظر دوربین، گلکسی S24 Ultra با لنز 200 مگاپیکسلی پیشتاز است. آیفون 15 Pro Max بهترین پردازنده را دارد و شیائومی 14 Ultra با نصف قیمت رقبا تقریباً تمام قابلیت&zwnj;های آن&zwnj;ها را ارائه می&zwnj;دهد. وان پلاس 12 نیز با شارژ 100 واتی سریع&zwnj;ترین شارژ را دارد.', '2', '../image/article-uploads/686c0d2da2bce.jpeg', 'active', '12', '2024-01-25 16:20:00');
INSERT INTO `articles` VALUES ('6', 'هدفون بی‌سیم یا با سیم؟ راهنمای انتخاب بهترین گزینه', 'انتخاب بین هدفون بی&zwnj;سیم و با سیم به نیازهای شما بستگی دارد. اگر کیفیت صدای عالی و تاخیر صفر می&zwnj;خواهید، هدفون&zwnj;های با سیم مانند Beyerdynamic DT 990 Pro انتخاب بهتری هستند. برای استفاده روزمره و همراهی، هدفون&zwnj;های بی&zwnj;سیم مانند سونی WH-1000XM5 یا اپل AirPods Max راحتی بیشتری دارند. برای گیمینگ نیز مدل&zwnj;های بی&zwnj;سیم با فناوری&zwnj;های کم&zwnj;تاخیر مانند Razer Barracuda X گزینه مناسبی هستند.', '2', '../image/article-uploads/686c0d844d851.jpeg', 'active', '12', '2023-11-15 14:10:00');
INSERT INTO `articles` VALUES ('7', '10 ترفند مخفی در اندروید 14 که باید بدانید', 'اندروید 14 ویژگی&zwnj;های مخفی زیادی دارد که بسیاری از کاربران از آن&zwnj;ها بی&zwnj;خبرند. با فعال کردن حالت توسعه&zwnj;دهنده و استفاده از گزینه &laquo;ساعت شبکه&raquo;، می&zwnj;توانید سرعت اینترنت خود را در نوار وضعیت ببینید. با نگه داشتن دکمه پاور می&zwnj;توانید به منوی سریع&zwnj;تر دسترسی پیدا کنید. همچنین با کشیدن دو انگشت از بالای صفحه می&zwnj;توانید سریع&zwnj;تر به تنظیمات سریع دسترسی داشته باشید. این مقاله به بررسی 10 ترفند کاربردی اندروید 14 می&zwnj;پردازد.', '3', '../image/article-uploads/686c0d03b355b.jpeg', 'active', '13', '2024-02-10 09:30:00');
INSERT INTO `articles` VALUES ('8', 'چگونه عمر باتری لپتاپ خود را افزایش دهیم؟', 'برای افزایش عمر باتری لپتاپ، ابتدا روشنایی صفحه نمایش را کاهش دهید و حالت صرفه&zwnj;جویی در انرژی را فعال کنید. برنامه&zwnj;های پس&zwnj;زمینه غیرضروری را ببندید و از حالت پرتابل برای USBها استفاده نکنید. به&zwnj;روزرسانی&zwnj;های سیستم عامل و درایورها را نصب کنید و در صورت امکان از SSD به جای HDD استفاده کنید. همچنین حرارت لپتاپ را کنترل کنید، زیرا گرمای زیاد سریع&zwnj;تر باتری را تخلیه می&zwnj;کند. این مقاله به بررسی 15 روش عملی برای افزایش عمر باتری می&zwnj;پردازد.', '3', '../image/article-uploads/686c0d6d9fcba.jpeg', 'active', '13', '2023-12-18 13:45:00');
INSERT INTO `articles` VALUES ('9', 'تنظیمات حرفه‌ای دوربین DSLR برای عکاسی در شب', 'عکاسی در شب با دوربین&zwnj;های DSLR نیاز به تنظیمات خاصی دارد. ابتدا دوربین را روی سه&zwnj;پایه محکم قرار دهید. حالت عکاسی را روی Manual تنظیم کنید. ISO را بین 800 تا 3200 انتخاب کنید (بسته به نویز دوربین). دیافراگم را روی پایین&zwnj;ترین عدد ممکن (مثلاً f/2.8) قرار دهید و سرعت شاتر را بین 5 تا 30 ثانیه تنظیم کنید. استفاده از تایمر یا ریموت کنترل نیز از لرزش جلوگیری می&zwnj;کند. این مقاله به طور کامل به آموزش تنظیمات حرفه&zwnj;ای عکاسی شبانه می&zwnj;پردازد.', '3', '../image/article-uploads/686c0d55cc0f2.jpeg', 'active', '13', '2024-01-05 17:20:00');
INSERT INTO `articles` VALUES ('10', 'بررسی تخصصی گلکسی S24 Ultra: آیا بهترین گوشی اندرویدی است؟', 'در این بررسی عمیق، گلکسی S24 Ultra را از همه جنبه&zwnj;ها تست کرده&zwnj;ایم. دوربین 200 مگاپیکسلی با لنز جدید تله&zwnj;فوتو 10x عملکرد خیره&zwnj;کننده&zwnj;ای دارد. پردازنده Snapdragon 8 Gen 3 برای Galaxy در بنچمارک&zwnj;ها رکوردشکنی کرده است. صفحه نمایش Dynamic AMOLED 2X با روشنایی 2600 نیت در نور مستقیم آفتاب کاملاً قابل مشاهده است. باتری 5000mAh با شارژ 45 واتی در تست ما حدود 8 ساعت استفاده سنگین دوام آورده است.', '4', '../image/article-uploads/686c0cfa68b59.jpeg', 'active', '14', '2024-02-15 10:15:00');
INSERT INTO `articles` VALUES ('11', 'بررسی عملی مک‌بوک پرو 16 اینچ M3 Max: قدرت بی‌نظیر', 'مک&zwnj;بوک پرو 16 اینچ با تراشه M3 Max در تست&zwnj;های ما عملکردی فراتر از بسیاری از دسکتاپ&zwnj;ها داشته است. پردازنده 16 هسته&zwnj;ای و GPU 40 هسته&zwnj;ای آن حتی در سنگین&zwnj;ترین کارهای تدوین ویدیو و رندر سه&zwnj;بعدی هم به مشکل برنخورد. صفحه نمایش Liquid Retina XDR با نرخ نوسازی 120Hz تجربه&zwnj;ای نرم و لذت&zwnj;بخش ارائه می&zwnj;دهد. باتری آن در حالت استفاده معمولی تا 18 ساعت دوام می&zwnj;آورد. تنها نقطه ضعف آن قیمت بسیار بالاست.', '4', '../image/article-uploads/686c0d225e018.jpeg', 'active', '14', '2024-01-30 14:50:00');
INSERT INTO `articles` VALUES ('12', 'بررسی جامع تلویزیون LG OLED C3: بهترین برای سینمای خانگی', 'تلویزیون LG OLED C3 با صفحه نمایش 65 اینچ در تست&zwnj;های ما بهترین کیفیت تصویر را در رده خود ارائه داده است. تکنولوژی OLED با کنتراست بی&zwnj;نهایت و سیاهی&zwnj;های واقعی، تصاویری خیره&zwnj;کننده خلق می&zwnj;کند. سیستم صدای دالبی اتمس با 60 وات قدرت، تجربه سینمایی کاملی ارائه می&zwnj;دهد. ورودی&zwnj;های HDMI 2.1 با نرخ نوسازی 120Hz برای کنسول&zwnj;های نسل جدید ایده&zwnj;آل هستند. تنها ضعف آن روشنایی کمتر در محیط&zwnj;های بسیار پرنور است.', '4', '../image/article-uploads/686c0d61e56dc.jpeg', 'active', '14', '2023-12-22 11:30:00');
INSERT INTO `articles` VALUES ('13', 'چگونه خانه خود را هوشمند کنیم؟ راهنمای جامع مبتدیان', 'خانه&zwnj;های هوشمند دیگر یک رویا نیستند. با بودجه&zwnj;های مختلف می&zwnj;توانید خانه خود را هوشمند کنید. ابتدا با یک دستیار صوتی مانند Google Home یا Amazon Echo شروع کنید. سپس چراغ&zwnj;های هوشمند مانند فیلیپس Hue را اضافه کنید. ترموستات&zwnj;های هوشمند مانند Nest مصرف انرژی را بهینه می&zwnj;کنند. قفل&zwnj;ها و دوربین&zwnj;های هوشمند امنیت خانه را افزایش می&zwnj;دهند. در این مقاله به بررسی کامل راه&zwnj;های هوشمندسازی خانه با بودجه&zwnj;های مختلف پرداخته&zwnj;ایم.', '5', '../image/article-uploads/686c0d0d41463.jpeg', 'active', '15', '2024-02-05 08:45:00');
INSERT INTO `articles` VALUES ('14', 'تأثیر فناوری بر سلامت روان: چگونه از آن به نفع خود استفاده کنیم؟', 'فناوری هم می&zwnj;تواند برای سلامت روان مضر باشد و هم مفید. استفاده بیش از حد از شبکه&zwnj;های اجتماعی باعث اضطراب و افسردگی می&zwnj;شود. اما برنامه&zwnj;های مدیتیشن مانند Headspace یا Calm می&zwnj;توانند به آرامش ذهن کمک کنند. ساعت&zwnj;های هوشمند با ردیابی خواب و استرس، آگاهی شما را افزایش می&zwnj;دهند. در این مقاله به بررسی راه&zwnj;های استفاده سالم از فناوری برای بهبود سلامت روان پرداخته&zwnj;ایم.', '5', '../image/article-uploads/686c0d37b0726.jpeg', 'active', '15', '2024-01-18 12:20:00');
INSERT INTO `articles` VALUES ('15', 'امنیت دیجیتال در سال 2024: چگونه از اطلاعات خود محافظت کنیم؟', 'با افزایش حملات سایبری، امنیت دیجیتال بیش از هر زمان دیگری اهمیت دارد. همیشه از رمزهای عبور قوی و منحصر به فرد استفاده کنید و احراز هویت دو مرحله&zwnj;ای را فعال کنید. VPN می&zwnj;تواند حریم خصوصی شما را در اینترنت حفظ کند. به&zwnj;روزرسانی&zwnj;های امنیتی را سریع&zwnj;تر نصب کنید و از نرم&zwnj;افزارهای ضدویروس معتبر استفاده کنید. در این مقاله 20 راهکار عملی برای افزایش امنیت دیجیتال در سال 2024 ارائه شده است.', '5', '../image/article-uploads/686c0d1739896.jpeg', 'active', '15', '2024-02-01 15:10:00');

--
-- Table structure for table `categories`
--
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--
INSERT INTO `categories` VALUES ('1', 'گوشی‌های هوشمند', NULL, 'انواع گوشی‌های هوشمند از برندهای معتبر', '2025-07-05 10:11:28', '../image/category-images/IMG_20230618_161223_222.jpg');
INSERT INTO `categories` VALUES ('2', 'لپتاپ و کامپیوتر', NULL, 'لپتاپ‌های شخصی، گیمینگ و کامپیوترهای رومیزی', '2025-07-05 10:11:28', '../image/category-images/IMG_20220812_211709_751.jpg');
INSERT INTO `categories` VALUES ('3', 'تبلت‌ها', NULL, 'انواع تبلت‌های اندروید و آیپد', '2025-07-05 10:11:28', '../image/category-images/IMG_20220929_120947_981.jpg');
INSERT INTO `categories` VALUES ('4', 'لوازم جانبی موبایل', NULL, 'کیف، کاور، پاوربانک و سایر لوازم جانبی موبایل', '2025-07-05 10:11:28', '../image/category-images/IMG_20220812_211611_669.jpg');
INSERT INTO `categories` VALUES ('5', 'هدفون و هندزفری', NULL, 'انواع هدفون بی‌سیم و با سیم، هندزفری', '2025-07-05 10:11:28', '../image/category-images/IMG_20220906_010302_722.jpg');
INSERT INTO `categories` VALUES ('6', 'تلویزیون و سینمای خانگی', NULL, 'تلویزیون‌های هوشمند، سینمای خانگی و پروژکتور', '2025-07-05 10:11:28', '../image/category-images/IMG_20220814_213824_452.jpg');
INSERT INTO `categories` VALUES ('7', 'کنسول‌های بازی', NULL, 'پلی‌استیشن، ایکس‌باکس و کنسول‌های بازی', '2025-07-05 10:11:28', '../image/category-images/IMG_20220723_180252_069.jpg');
INSERT INTO `categories` VALUES ('8', 'دوربین و عکاسی', NULL, 'دوربین‌های دیجیتال، لنز و تجهیزات عکاسی', '2025-07-05 10:11:28', '../image/category-images/IMG_20220906_010305_167.jpg');
INSERT INTO `categories` VALUES ('9', 'لوازم جانبی کامپیوتر', NULL, 'ماوس، کیبورد، مانیتور و سایر لوازم جانبی', '2025-07-05 10:11:28', '../image/category-images/IMG_20230128_225027_565.jpg');
INSERT INTO `categories` VALUES ('10', 'گجت‌های هوشمند', NULL, 'ساعت هوشمند، دستبند هوشمند و سایر گجت‌ها', '2025-07-05 10:11:28', '../image/category-images/IMG_20220729_005158_330.jpg');
INSERT INTO `categories` VALUES ('11', 'اخبار تکنولوژی', NULL, 'آخرین اخبار و تحولات دنیای فناوری و گجت‌های دیجیتال', '2025-07-05 10:58:59', '../image/category-images/IMG_20221114_172402_764.jpg');
INSERT INTO `categories` VALUES ('12', 'راهنمای خرید', NULL, 'مقایسه محصولات و راهنمای انتخاب بهترین گزینه برای خرید', '2025-07-05 10:58:59', '../image/category-images/IMG_20220721_025508_027.jpg');
INSERT INTO `categories` VALUES ('13', 'آموزش و ترفندها', NULL, 'آموزش استفاده از محصولات و ترفندهای کاربردی', '2025-07-05 10:58:59', '../image/category-images/IMG_20220803_203841_948.jpg');
INSERT INTO `categories` VALUES ('14', 'بررسی محصولات', NULL, 'بررسی تخصصی و تست محصولات الکترونیکی', '2025-07-05 10:58:59', '../image/category-images/IMG_20221024_212927_218.jpg');
INSERT INTO `categories` VALUES ('15', 'سبک زندگی دیجیتال', NULL, 'مقالات مرتبط با تاثیر فناوری بر زندگی روزمره', '2025-07-05 10:58:59', '../image/category-images/IMG_20220729_005201_977.jpg');

--
-- Table structure for table `consultationmessages`
--
DROP TABLE IF EXISTS `consultationmessages`;
CREATE TABLE `consultationmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consultation_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `consultation_id` (`consultation_id`),
  KEY `sender_id` (`sender_id`),
  CONSTRAINT `consultationmessages_ibfk_1` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `consultationmessages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultationmessages`
--
INSERT INTO `consultationmessages` VALUES ('16', '5', '21', 'رظرزطظ', '2025-07-30 11:44:40');
INSERT INTO `consultationmessages` VALUES ('17', '5', '21', 'ظطزرطزرظطزر', '2025-07-30 11:44:53');
INSERT INTO `consultationmessages` VALUES ('18', '5', '21', 'سلام', '2025-07-31 17:04:18');

--
-- Table structure for table `consultations`
--
DROP TABLE IF EXISTS `consultations`;
CREATE TABLE `consultations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `advisor_id` int(11) NOT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `consultation_date` datetime DEFAULT NULL,
  `status` enum('pending','confirmed','completed','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `advisor_id` (`advisor_id`),
  CONSTRAINT `consultations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `consultations_ibfk_2` FOREIGN KEY (`advisor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultations`
--
INSERT INTO `consultations` VALUES ('5', '21', '21', 'dv', 'cxvvc', '2025-08-09 12:11:00', 'completed', '2025-07-28 12:11:12', '2025-07-31 17:04:24');

--
-- Table structure for table `contactmessages`
--
DROP TABLE IF EXISTS `contactmessages`;
CREATE TABLE `contactmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contactmessages`
--
INSERT INTO `contactmessages` VALUES ('1', 'Ahmad', 'Ahmad@gmail.com', 'Hello Good morning.', '2025-07-11 18:03:25');
INSERT INTO `contactmessages` VALUES ('4', 'Hoseiin', 'mh.mirzaii1382@Gmail.com', '123', '2025-07-30 12:50:30');

--
-- Table structure for table `discounts`
--
DROP TABLE IF EXISTS `discounts`;
CREATE TABLE `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `discount_type` enum('percentage','fixed') NOT NULL,
  `discount_value` decimal(12,2) NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `discounts_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `discounts`
--
INSERT INTO `discounts` VALUES ('71', '32', 'percentage', '20.00', '2025-07-21 13:08:00', '2027-08-21 13:08:00');
INSERT INTO `discounts` VALUES ('72', '12', 'percentage', '20.00', '2025-07-21 13:09:00', '2027-07-23 13:09:00');
INSERT INTO `discounts` VALUES ('73', '11', 'percentage', '20.00', '2025-07-21 13:10:00', '2027-12-24 13:10:00');
INSERT INTO `discounts` VALUES ('74', '14', 'percentage', '20.00', '2025-07-21 13:10:00', '2027-12-17 13:10:00');
INSERT INTO `discounts` VALUES ('75', '13', 'percentage', '20.00', '2025-07-21 13:10:00', '2027-08-13 13:10:00');
INSERT INTO `discounts` VALUES ('76', '15', 'percentage', '20.00', '2025-07-21 13:11:00', '2027-08-13 13:11:00');
INSERT INTO `discounts` VALUES ('77', '27', 'percentage', '20.00', '2025-07-21 13:11:00', '2027-12-17 13:12:00');
INSERT INTO `discounts` VALUES ('78', '26', 'percentage', '20.00', '2025-07-21 13:12:00', '2027-11-17 13:12:00');
INSERT INTO `discounts` VALUES ('79', '30', 'percentage', '20.00', '2025-07-21 13:12:00', '2027-08-13 13:12:00');
INSERT INTO `discounts` VALUES ('80', '45', 'percentage', '20.00', '2025-07-21 13:13:00', '2027-08-27 13:13:00');
INSERT INTO `discounts` VALUES ('81', '47', 'percentage', '20.00', '2025-07-21 13:13:00', '2027-07-08 13:13:00');
INSERT INTO `discounts` VALUES ('82', '34', 'percentage', '20.00', '2025-07-21 13:13:00', '2027-08-13 13:13:00');
INSERT INTO `discounts` VALUES ('83', '50', 'percentage', '20.00', '2025-07-21 13:14:00', '2027-07-07 13:14:00');
INSERT INTO `discounts` VALUES ('84', '37', 'percentage', '20.00', '2025-07-21 13:14:00', '2027-08-20 13:14:00');
INSERT INTO `discounts` VALUES ('85', '38', 'percentage', '20.00', '2025-07-21 13:14:00', '2027-11-25 13:14:00');
INSERT INTO `discounts` VALUES ('86', '36', 'percentage', '20.00', '2025-07-21 13:14:00', '2027-08-20 13:15:00');
INSERT INTO `discounts` VALUES ('87', '48', 'percentage', '20.00', '2025-07-21 13:15:00', '2027-08-27 13:15:00');
INSERT INTO `discounts` VALUES ('88', '46', 'percentage', '20.00', '2025-07-21 13:15:00', '2027-12-31 13:15:00');
INSERT INTO `discounts` VALUES ('89', '40', 'percentage', '20.00', '2025-07-21 13:15:00', '2027-08-27 13:16:00');
INSERT INTO `discounts` VALUES ('90', '29', 'percentage', '20.00', '2025-07-21 13:16:00', '2027-09-16 13:16:00');
INSERT INTO `discounts` VALUES ('91', '3', 'percentage', '10.00', '2025-07-28 13:25:00', '2029-03-15 13:25:00');

--
-- Table structure for table `faqs`
--
DROP TABLE IF EXISTS `faqs`;
CREATE TABLE `faqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `category` varchar(50) NOT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faqs`
--
INSERT INTO `faqs` VALUES ('1', 'چگونه حساب کاربری جدید ایجاد کنم؟', 'در صفحه اصلی سایت روی گزینه \"ثبت نام\" کلیک کنید. سپس اطلاعات خواسته شده شامل نام، ایمیل و رمز عبور را وارد نمایید. پس از تایید ایمیل، حساب شما فعال خواهد شد.', 'حساب کاربری', 'ثبت نام, ورود', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('2', 'چگونه رمز عبورم را تغییر دهم؟', 'به صفحه \"فراموشی رمز عبور\" بروید و ایمیل خود را وارد کنید. لینک تغییر رمز به ایمیل شما ارسال می‌شود. با کلیک روی این لینک می‌توانید رمز جدید تعیین کنید.', 'حساب کاربری', 'رمز عبور, امنیت', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('3', 'چرا نمی‌توانم وارد حساب کاربری ام شوم؟', 'ممکن است رمز عبور را اشتباه وارد کرده باشید یا حساب شما موقتاً قفل شده باشد. از صحت ایمیل و رمز عبور اطمینان حاصل کنید یا از گزینه \"فراموشی رمز عبور\" استفاده نمایید.', 'حساب کاربری', 'ورود, مشکل', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('4', 'چگونه می‌توانم سفارشم را پیگیری کنم؟', 'پس از ورود به حساب کاربری، به بخش \"سفارشات من\" مراجعه کنید. شماره پیگیری سفارش و وضعیت آن در این بخش قابل مشاهده است. همچنین می‌توانید با شماره پشتیبانی تماس بگیرید.', 'سفارشات', 'پیگیری, ارسال', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('5', 'آیا امکان تغییر یا لغو سفارش وجود دارد؟', 'تا قبل از ارسال سفارش می‌توانید آن را تغییر یا لغو کنید. پس از ارسال، تنها امکان مرجوعی کالا طبق شرایط بازگشت وجود دارد.', 'سفارشات', 'تغییر, لغو', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('6', 'حداکثر زمان ثبت سفارش چه زمانی است؟', 'سفارشات تا ساعت 16 هر روز برای ارسال در همان روز پردازش می‌شوند. سفارشات بعد از این ساعت در روز کاری بعد ارسال خواهند شد.', 'سفارشات', 'زمان, تحویل', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('7', 'چه روش‌های پرداختی پذیرفته می‌شود؟', 'ما پرداخت آنلاین با کارت‌های عضو شتاب، پرداخت در محل و کیف پول الکترونیکی را می‌پذیریم. همچنین امکان پرداخت از طریق رمزارزها نیز وجود دارد.', 'پرداخت', 'درگاه, کارت', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('8', 'آیا پرداخت در محل امن است؟', 'بله، مبلغ سفارش فقط پس از بررسی و تأیید کالا توسط شما دریافت می‌شود. مأمور ارسال دارای دستگاه کارتخوان همراه است.', 'پرداخت', 'نقدی, اعتبار', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('9', 'چرا پرداخت آنلاین من ناموفق بود؟', 'ممکن است محدودیت‌های بانکی داشته باشید یا اطلاعات کارت را اشتباه وارد کرده باشید. همچنین موجودی کافی و صحت CVV2 را بررسی کنید.', 'پرداخت', 'خطا, بانک', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('10', 'هزینه ارسال چگونه محاسبه می‌شود؟', 'هزینه ارسال بر اساس وزن سفارش، مسافت و روش ارسال انتخابی شما محاسبه می‌شود. برای سفارشات بالای 500 هزار تومان، ارسال رایگان است.', 'ارسال', 'هزینه, پست', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('11', 'مدت زمان تحویل سفارش چقدر است؟', 'در تهران 24 ساعت و در شهرستان‌ها 2-3 روز کاری پس از ثبت سفارش می‌باشد. این زمان ممکن است در شرایط خاص مانند تعطیلات تغییر کند.', 'ارسال', 'زمان, شهرستان', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('12', 'آیا امکان ارسال به خارج از کشور وجود دارد؟', 'بله، با هزینه و زمان ارسال متفاوت. لطفاً قبل از سفارش با پشتیبانی تماس بگیرید تا شرایط ارسال بین‌المللی را برای شما توضیح دهند.', 'ارسال', 'خارج, بین‌المللی', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('13', 'شرایط بازگرداندن کالا چیست؟', 'کالا باید در شرایط اولیه و بدون استفاده باشد. درخواست مرجوعی باید حداکثر تا 7 روز پس از تحویل ثبت شود. هزینه ارسال مرجوعی بر عهده مشتری است.', 'بازگشت', 'مرجوعی, شرایط', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('14', 'چقدر طول می‌کشد تا مبلغ مرجوعی به حسابم برگردد؟', 'پس از تأیید مرجوعی در انبار، حداکثر 72 ساعت کاری زمان می‌برد تا مبلغ به حساب شما واریز شود.', 'بازگشت', 'عودت, پرداخت', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('15', 'آیا همه کالاها قابل بازگشت هستند؟', 'خیر، برخی کالاهای خاص مانند لوازم بهداشتی و نرم‌افزارهای فعال‌شده قابل بازگشت نیستند. شرایط کامل در صفحه \"قوانین بازگشت کالا\" ذکر شده است.', 'بازگشت', 'استثنا, محدودیت', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('16', 'گارانتی محصولات چگونه است؟', 'اکثر محصولات ما بین 6 تا 24 ماه گارانتی دارند. کارت گارانتی همراه کالا ارسال می‌شود و باید توسط مشتری امضا شود.', 'گارانتی', 'ضمانت, تعمیر', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('17', 'چگونه از خدمات گارانتی استفاده کنم؟', 'به بخش \"درخواست گارانتی\" در سایت مراجعه و فرم مربوطه را پر کنید. همکاران ما در اسرع وقت با شما تماس خواهند گرفت.', 'گارانتی', 'فرم, تعویض', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('18', 'آیا امکان تمدید گارانتی وجود دارد؟', 'بله، برای برخی محصولات می‌توانید با پرداخت هزینه، گارانتی را تا 12 ماه دیگر تمدید کنید. لطفاً با پشتیبانی تماس بگیرید.', 'گارانتی', 'تمدید, هزینه', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('19', 'چگونه می‌توانم محصولات را مقایسه کنم؟', 'در صفحه دسته‌بندی محصولات، گزینه \"مقایسه\" وجود دارد. حداکثر 4 محصول را می‌توانید همزمان مقایسه کنید.', 'محصولات', 'مشخصات, ویژگی', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('20', 'آیا محصولات شما اصل هستند؟', 'بله، تمام محصولات ما از واردکنندگان رسمی تهیه شده و دارای گارانتی معتبر هستند. ما هیچ گونه محصول تقلبی یا قاچاق عرضه نمی‌کنیم.', 'محصولات', 'اصل, اورجینال', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('21', 'چرا قیمت برخی محصولات تغییر می‌کند؟', 'قیمت‌ها به دلیل نوسانات ارز، تغییرات مالیاتی و سیاست‌های فروش ممکن است تغییر کنند. قیمت نهایی همان است که در زمان تسویه حساب محاسبه می‌شود.', 'محصولات', 'نوسان, دلار', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('22', 'چگونه از تخفیف‌ها مطلع شوم؟', 'با عضویت در خبرنامه سایت و پیج‌های اجتماعی ما، از آخرین تخفیف‌ها و پیشنهادهای ویژه باخبر خواهید شد.', 'تخفیف', 'کد, خبرنامه', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('23', 'آیا می‌توانم چند کد تخفیف را ترکیب کنم؟', 'خیر، در هر سفارش فقط می‌توانید از یک کد تخفیف استفاده کنید. سیستم به صورت خودکار بالاترین تخفیف ممکن را اعمال می‌کند.', 'تخفیف', 'ترکیب, اعتبار', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('24', 'کدهای تخفیف چه مدت اعتبار دارند؟', 'اعتبار کدهای تخفیف معمولاً بین 1 تا 30 روز است. تاریخ انقضای هر کد در هنگام ارسال به شما اعلام می‌شود.', 'تخفیف', 'انقضا, مدت', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('25', 'اطلاعات من چگونه محافظت می‌شود؟', 'ما از پروتکل SSL و رمزنگاری پیشرفته برای محافظت از اطلاعات شما استفاده می‌کنیم. اطلاعات پرداخت مستقیماً به درگاه بانکی ارسال می‌شود و نزد ما ذخیره نمی‌شود.', 'امنیت', 'SSL, رمزنگاری', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('26', 'آیا اطلاعات من به اشتراک گذاشته می‌شود؟', 'خیر، ما اطلاعات شخصی شما را به هیچ شخص یا سازمان دیگری نمی‌فروشیم یا منتقل نمی‌کنیم. جز برای مقاصد ضروری مانند ارسال سفارش.', 'امنیت', 'حریم, شخصی', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('27', 'چگونه می‌توانم حسابم را امن‌تر کنم؟', 'استفاده از رمز عبور قوی، فعال‌سازی تأیید دو مرحله‌ای و عدم اشتراک گذاری اطلاعات ورود، امنیت حساب شما را افزایش می‌دهد.', 'امنیت', 'حساب, تأیید', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('28', 'چگونه با پشتیبانی تماس بگیرم؟', 'می‌توانید از طریق تلفن 021-12345678، چت آنلاین سایت یا ایمیل support@digitalshop.ir با ما در ارتباط باشید. ساعت کاری: 9 صبح تا 5 بعدازظهر.', 'تماس', 'پشتیبانی, تلفن', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('29', 'آیا نمایندگی‌های فیزیکی دارید؟', 'بله، آدرس فروشگاه‌های فیزیکی ما در صفحه \"تماس با ما\" درج شده است. همچنین می‌توانید از بخش \"جستجوی نمایندگی\" استفاده کنید.', 'تماس', 'آدرس, فروشگاه', '2025-07-05 11:07:59', '2025-07-05 11:07:59');
INSERT INTO `faqs` VALUES ('30', 'چقدر طول می‌کشد تا به پیام من پاسخ داده شود؟', 'در ساعات کاری، معمولاً ظرف 2 ساعت پاسخ داده می‌شود. در خارج از ساعات کاری، پاسخ‌ها در اولین ساعت کاری روز بعد ارسال می‌شوند.', 'تماس', 'زمان, پاسخ', '2025-07-05 11:07:59', '2025-07-05 11:07:59');

--
-- Table structure for table `favorites`
--
DROP TABLE IF EXISTS `favorites`;
CREATE TABLE `favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`product_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favorites`
--
INSERT INTO `favorites` VALUES ('193', '21', '40', '2025-07-31 17:06:55');
INSERT INTO `favorites` VALUES ('194', '21', '36', '2025-07-31 17:06:57');
INSERT INTO `favorites` VALUES ('195', '21', '37', '2025-07-31 17:06:58');

--
-- Table structure for table `notifications`
--
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('new_user','new_order','new_message','new_review','new_consultation','other') NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `is_dismissed` tinyint(1) DEFAULT 0,
  `related_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=527 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--
INSERT INTO `notifications` VALUES ('420', 'new_user', 'کاربر جدید', 'کاربر جدید با نام Test ثبت نام کرد', '1', '1', '25', '2025-07-23 09:17:19', '2025-07-23 10:54:44');
INSERT INTO `notifications` VALUES ('421', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '1', '153', '2025-07-24 17:26:43', '2025-07-25 12:14:55');
INSERT INTO `notifications` VALUES ('422', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 153 از pending به processing تغییر کرد', '1', '1', '153', '2025-07-24 17:27:58', '2025-07-25 12:14:55');
INSERT INTO `notifications` VALUES ('423', 'new_order', 'پرداخت موفق', 'پرداخت سفارش شماره 153 توسط کاربر Hoseiin Mirzaii با مبلغ 10500000 انجام شد', '1', '1', '153', '2025-07-24 17:27:58', '2025-07-25 12:14:55');
INSERT INTO `notifications` VALUES ('424', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '1', '154', '2025-07-24 17:28:18', '2025-07-25 12:14:55');
INSERT INTO `notifications` VALUES ('425', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 154 از pending به processing تغییر کرد', '1', '1', '154', '2025-07-24 17:28:27', '2025-07-25 12:14:55');
INSERT INTO `notifications` VALUES ('426', 'new_order', 'پرداخت موفق', 'پرداخت سفارش شماره 154 توسط کاربر Hoseiin Mirzaii با مبلغ 10500000 انجام شد', '1', '1', '154', '2025-07-24 17:28:27', '2025-07-25 12:14:55');
INSERT INTO `notifications` VALUES ('427', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 153 از processing به shipped تغییر کرد', '1', '1', '153', '2025-07-24 17:29:20', '2025-07-25 12:15:01');
INSERT INTO `notifications` VALUES ('428', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 153 از shipped به completed تغییر کرد', '1', '1', '153', '2025-07-24 17:29:29', '2025-07-25 12:15:01');
INSERT INTO `notifications` VALUES ('429', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 154 از processing به shipped تغییر کرد', '1', '1', '154', '2025-07-24 17:29:36', '2025-07-25 12:15:00');
INSERT INTO `notifications` VALUES ('430', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 154 از shipped به completed تغییر کرد', '1', '1', '154', '2025-07-24 17:29:38', '2025-07-25 12:15:00');
INSERT INTO `notifications` VALUES ('431', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '1', '155', '2025-07-25 10:01:14', '2025-07-25 12:15:00');
INSERT INTO `notifications` VALUES ('432', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 155 از pending به processing تغییر کرد', '1', '1', '155', '2025-07-25 10:01:27', '2025-07-25 12:14:59');
INSERT INTO `notifications` VALUES ('433', 'new_order', 'پرداخت موفق', 'پرداخت سفارش شماره 155 توسط کاربر Hoseiin Mirzaii با مبلغ 1600000 انجام شد', '1', '1', '155', '2025-07-25 10:01:27', '2025-07-25 12:14:59');
INSERT INTO `notifications` VALUES ('434', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '1', '156', '2025-07-25 10:05:08', '2025-07-25 12:14:59');
INSERT INTO `notifications` VALUES ('435', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 156 از pending به processing تغییر کرد', '1', '0', '156', '2025-07-25 12:23:12', '2025-07-25 12:23:23');
INSERT INTO `notifications` VALUES ('436', 'new_order', 'پرداخت موفق', 'پرداخت سفارش شماره 156 توسط کاربر Hoseiin Mirzaii با مبلغ 4240000 انجام شد', '1', '0', '156', '2025-07-25 12:23:12', '2025-07-25 12:23:23');
INSERT INTO `notifications` VALUES ('437', 'new_consultation', 'درخواست مشاوره جدید', 'درخواست مشاوره جدید از کاربر Hoseiin Mirzaii با موضوع 456', '1', '0', '4', '2025-07-25 19:25:23', '2025-07-25 19:27:49');
INSERT INTO `notifications` VALUES ('438', 'new_message', 'پیام جدید در مشاوره', 'پیام جدید در مشاوره با موضوع 456', '1', '0', '4', '2025-07-25 19:25:33', '2025-07-25 19:27:49');
INSERT INTO `notifications` VALUES ('439', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '0', '157', '2025-07-26 19:55:31', '2025-07-27 17:28:49');
INSERT INTO `notifications` VALUES ('440', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 157 از pending به processing تغییر کرد', '1', '0', '157', '2025-07-26 19:55:41', '2025-07-27 17:28:49');
INSERT INTO `notifications` VALUES ('441', 'new_order', 'پرداخت موفق', 'پرداخت سفارش شماره 157 توسط کاربر Hoseiin Mirzaii با مبلغ 12000000 انجام شد', '1', '0', '157', '2025-07-26 19:55:41', '2025-07-27 17:28:49');
INSERT INTO `notifications` VALUES ('442', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 155 از processing به shipped تغییر کرد', '1', '0', '155', '2025-07-26 19:56:09', '2025-07-27 17:28:49');
INSERT INTO `notifications` VALUES ('443', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 155 از shipped به completed تغییر کرد', '1', '0', '155', '2025-07-26 19:56:13', '2025-07-27 17:28:49');
INSERT INTO `notifications` VALUES ('444', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 156 از processing به shipped تغییر کرد', '1', '0', '156', '2025-07-26 19:56:15', '2025-07-27 17:28:49');
INSERT INTO `notifications` VALUES ('445', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 156 از shipped به completed تغییر کرد', '1', '0', '156', '2025-07-26 19:56:16', '2025-07-27 17:28:49');
INSERT INTO `notifications` VALUES ('446', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 157 از processing به shipped تغییر کرد', '1', '0', '157', '2025-07-26 19:56:35', '2025-07-27 17:28:49');
INSERT INTO `notifications` VALUES ('447', 'other', 'پیام جدید از تماس با ما', 'پیام جدید از Hoseiin با موضوع hi', '1', '0', '2', '2025-07-27 17:28:07', '2025-07-27 17:28:49');
INSERT INTO `notifications` VALUES ('448', 'other', 'تغییر تصویر پروفایل', 'کاربر محمد احمدی تصویر پروفایل خود را تغییر داد', '1', '0', '1', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('449', 'other', 'تغییر تصویر پروفایل', 'کاربر فاطمه محمدی تصویر پروفایل خود را تغییر داد', '1', '0', '2', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('450', 'other', 'تغییر تصویر پروفایل', 'کاربر علی رضایی تصویر پروفایل خود را تغییر داد', '1', '0', '3', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('451', 'other', 'تغییر تصویر پروفایل', 'کاربر زهرا حسینی تصویر پروفایل خود را تغییر داد', '1', '0', '4', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('452', 'other', 'تغییر تصویر پروفایل', 'کاربر رضا کریمی تصویر پروفایل خود را تغییر داد', '1', '0', '5', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('453', 'other', 'تغییر تصویر پروفایل', 'کاربر نازنین نوروزی تصویر پروفایل خود را تغییر داد', '1', '0', '6', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('454', 'other', 'تغییر تصویر پروفایل', 'کاربر امیرحسین فلاحی تصویر پروفایل خود را تغییر داد', '1', '0', '7', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('455', 'other', 'تغییر تصویر پروفایل', 'کاربر سارا موسوی تصویر پروفایل خود را تغییر داد', '1', '0', '8', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('456', 'other', 'تغییر تصویر پروفایل', 'کاربر حسین اکبری تصویر پروفایل خود را تغییر داد', '1', '0', '9', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('457', 'other', 'تغییر تصویر پروفایل', 'کاربر لیلا صادقی تصویر پروفایل خود را تغییر داد', '1', '0', '10', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('458', 'other', 'تغییر تصویر پروفایل', 'کاربر مهدی قربانی تصویر پروفایل خود را تغییر داد', '1', '0', '11', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('459', 'other', 'تغییر تصویر پروفایل', 'کاربر مریم جعفری تصویر پروفایل خود را تغییر داد', '1', '0', '12', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('460', 'other', 'تغییر تصویر پروفایل', 'کاربر پویا محمودی تصویر پروفایل خود را تغییر داد', '1', '0', '13', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('461', 'other', 'تغییر تصویر پروفایل', 'کاربر نرگس امینی تصویر پروفایل خود را تغییر داد', '1', '0', '14', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('462', 'other', 'تغییر تصویر پروفایل', 'کاربر امین طباطبایی تصویر پروفایل خود را تغییر داد', '1', '0', '15', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('463', 'other', 'تغییر تصویر پروفایل', 'کاربر هانیه مرادی تصویر پروفایل خود را تغییر داد', '1', '0', '16', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('464', 'other', 'تغییر تصویر پروفایل', 'کاربر محسن یوسفی تصویر پروفایل خود را تغییر داد', '1', '0', '17', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('465', 'other', 'تغییر تصویر پروفایل', 'کاربر الهام نوری تصویر پروفایل خود را تغییر داد', '1', '0', '18', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('466', 'other', 'تغییر تصویر پروفایل', 'کاربر سعید رحیمی تصویر پروفایل خود را تغییر داد', '1', '0', '19', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('467', 'other', 'تغییر تصویر پروفایل', 'کاربر نیلوفر شریفی تصویر پروفایل خود را تغییر داد', '1', '0', '20', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('468', 'other', 'تغییر تصویر پروفایل', 'کاربر Hoseiin Mirzaii تصویر پروفایل خود را تغییر داد', '1', '0', '21', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('469', 'other', 'تغییر تصویر پروفایل', 'کاربر Ahmad تصویر پروفایل خود را تغییر داد', '1', '0', '22', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('470', 'other', 'تغییر تصویر پروفایل', 'کاربر ali تصویر پروفایل خود را تغییر داد', '1', '0', '23', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('471', 'other', 'تغییر تصویر پروفایل', 'کاربر qqQ تصویر پروفایل خود را تغییر داد', '1', '0', '24', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('472', 'other', 'تغییر تصویر پروفایل', 'کاربر Test تصویر پروفایل خود را تغییر داد', '1', '0', '25', '2025-07-27 18:26:56', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('473', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '0', '158', '2025-07-27 18:38:13', '2025-07-27 19:28:44');
INSERT INTO `notifications` VALUES ('474', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 158 از pending به processing تغییر کرد', '1', '0', '158', '2025-07-27 19:33:47', '2025-07-27 19:52:15');
INSERT INTO `notifications` VALUES ('475', 'new_order', 'پرداخت موفق', 'پرداخت سفارش شماره 158 توسط کاربر Hoseiin Mirzaii با مبلغ 2800000 انجام شد', '1', '0', '158', '2025-07-27 19:33:47', '2025-07-27 19:52:15');
INSERT INTO `notifications` VALUES ('476', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '0', '159', '2025-07-28 10:08:44', '2025-07-28 10:20:05');
INSERT INTO `notifications` VALUES ('477', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 157 از shipped به completed تغییر کرد', '1', '1', '157', '2025-07-28 10:20:28', '2025-07-28 10:22:21');
INSERT INTO `notifications` VALUES ('478', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 158 از processing به shipped تغییر کرد', '1', '1', '158', '2025-07-28 10:20:29', '2025-07-28 10:22:20');
INSERT INTO `notifications` VALUES ('479', 'other', 'محصول جدید', 'محصول جدید با نام 1 در دسته‌بندی تبلت‌ها اضافه شد', '1', '0', '52', '2025-07-28 11:37:35', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('480', 'other', 'تغییر تصویر پروفایل', 'کاربر qqQ تصویر پروفایل خود را تغییر داد', '1', '0', '24', '2025-07-28 11:55:08', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('481', 'other', 'تغییر تصویر پروفایل', 'کاربر Test تصویر پروفایل خود را تغییر داد', '1', '0', '25', '2025-07-28 11:55:08', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('482', 'other', 'تغییر تصویر پروفایل', 'کاربر محمد احمدی تصویر پروفایل خود را تغییر داد', '1', '0', '1', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('483', 'other', 'تغییر تصویر پروفایل', 'کاربر فاطمه محمدی تصویر پروفایل خود را تغییر داد', '1', '0', '2', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('484', 'other', 'تغییر تصویر پروفایل', 'کاربر علی رضایی تصویر پروفایل خود را تغییر داد', '1', '0', '3', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('485', 'other', 'تغییر تصویر پروفایل', 'کاربر زهرا حسینی تصویر پروفایل خود را تغییر داد', '1', '0', '4', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('486', 'other', 'تغییر تصویر پروفایل', 'کاربر رضا کریمی تصویر پروفایل خود را تغییر داد', '1', '0', '5', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('487', 'other', 'تغییر تصویر پروفایل', 'کاربر نازنین نوروزی تصویر پروفایل خود را تغییر داد', '1', '0', '6', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('488', 'other', 'تغییر تصویر پروفایل', 'کاربر امیرحسین فلاحی تصویر پروفایل خود را تغییر داد', '1', '0', '7', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('489', 'other', 'تغییر تصویر پروفایل', 'کاربر سارا موسوی تصویر پروفایل خود را تغییر داد', '1', '0', '8', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('490', 'other', 'تغییر تصویر پروفایل', 'کاربر حسین اکبری تصویر پروفایل خود را تغییر داد', '1', '0', '9', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('491', 'other', 'تغییر تصویر پروفایل', 'کاربر لیلا صادقی تصویر پروفایل خود را تغییر داد', '1', '0', '10', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('492', 'other', 'تغییر تصویر پروفایل', 'کاربر مهدی قربانی تصویر پروفایل خود را تغییر داد', '1', '0', '11', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('493', 'other', 'تغییر تصویر پروفایل', 'کاربر مریم جعفری تصویر پروفایل خود را تغییر داد', '1', '0', '12', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('494', 'other', 'تغییر تصویر پروفایل', 'کاربر پویا محمودی تصویر پروفایل خود را تغییر داد', '1', '0', '13', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('495', 'other', 'تغییر تصویر پروفایل', 'کاربر نرگس امینی تصویر پروفایل خود را تغییر داد', '1', '0', '14', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('496', 'other', 'تغییر تصویر پروفایل', 'کاربر امین طباطبایی تصویر پروفایل خود را تغییر داد', '1', '0', '15', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('497', 'other', 'تغییر تصویر پروفایل', 'کاربر هانیه مرادی تصویر پروفایل خود را تغییر داد', '1', '0', '16', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('498', 'other', 'تغییر تصویر پروفایل', 'کاربر محسن یوسفی تصویر پروفایل خود را تغییر داد', '1', '0', '17', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('499', 'other', 'تغییر تصویر پروفایل', 'کاربر الهام نوری تصویر پروفایل خود را تغییر داد', '1', '0', '18', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('500', 'other', 'تغییر تصویر پروفایل', 'کاربر سعید رحیمی تصویر پروفایل خود را تغییر داد', '1', '0', '19', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('501', 'other', 'تغییر تصویر پروفایل', 'کاربر نیلوفر شریفی تصویر پروفایل خود را تغییر داد', '1', '0', '20', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('502', 'other', 'تغییر تصویر پروفایل', 'کاربر Hoseiin Mirzaii تصویر پروفایل خود را تغییر داد', '1', '0', '21', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('503', 'other', 'تغییر تصویر پروفایل', 'کاربر Ahmad تصویر پروفایل خود را تغییر داد', '1', '0', '22', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('504', 'other', 'تغییر تصویر پروفایل', 'کاربر ali تصویر پروفایل خود را تغییر داد', '1', '0', '23', '2025-07-28 11:56:31', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('505', 'new_consultation', 'درخواست مشاوره جدید', 'درخواست مشاوره جدید از کاربر Hoseiin Mirzaii با موضوع dv', '1', '0', '5', '2025-07-28 12:11:12', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('506', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '0', '160', '2025-07-28 12:39:25', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('507', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 160 از pending به processing تغییر کرد', '1', '0', '160', '2025-07-28 12:41:50', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('508', 'new_order', 'پرداخت موفق', 'پرداخت سفارش شماره 160 توسط کاربر Hoseiin Mirzaii با مبلغ 1600000 انجام شد', '1', '0', '160', '2025-07-28 12:41:50', '2025-07-28 12:49:23');
INSERT INTO `notifications` VALUES ('509', 'other', 'تخفیف جدید', 'تخفیف جدید برای محصول گوشی آیفون 14 Pro Max ثبت شد', '1', '0', '3', '2025-07-28 13:25:39', '2025-07-28 13:28:17');
INSERT INTO `notifications` VALUES ('510', 'other', 'تخفیف جدید', 'تخفیف جدید برای محصول گوشی آیفون 14 Pro Max ثبت شد', '1', '0', '3', '2025-07-28 13:27:18', '2025-07-28 13:28:17');
INSERT INTO `notifications` VALUES ('511', 'other', 'تخفیف جدید', 'تخفیف جدید برای محصول گوشی آیفون 14 Pro Max ثبت شد', '1', '0', '3', '2025-07-28 13:27:21', '2025-07-28 13:28:17');
INSERT INTO `notifications` VALUES ('512', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 158 از shipped به completed تغییر کرد', '1', '1', '158', '2025-07-28 13:28:33', '2025-07-30 11:45:06');
INSERT INTO `notifications` VALUES ('513', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 160 از processing به shipped تغییر کرد', '1', '1', '160', '2025-07-28 13:28:35', '2025-07-30 11:45:06');
INSERT INTO `notifications` VALUES ('514', 'new_consultation', 'درخواست مشاوره جدید', 'درخواست مشاوره جدید از کاربر Hoseiin Mirzaii با موضوع سشییییبلا', '1', '0', '6', '2025-07-30 11:43:50', '2025-07-30 11:45:06');
INSERT INTO `notifications` VALUES ('515', 'new_message', 'پیام جدید در مشاوره', 'پیام جدید در مشاوره با موضوع سشییییبلا', '1', '0', '6', '2025-07-30 11:43:55', '2025-07-30 11:45:06');
INSERT INTO `notifications` VALUES ('516', 'new_message', 'پیام جدید در مشاوره', 'پیام جدید در مشاوره با موضوع dv', '1', '0', '5', '2025-07-30 11:44:40', '2025-07-30 11:45:06');
INSERT INTO `notifications` VALUES ('517', 'new_message', 'پیام جدید در مشاوره', 'پیام جدید در مشاوره با موضوع dv', '1', '0', '5', '2025-07-30 11:44:53', '2025-07-30 11:45:06');
INSERT INTO `notifications` VALUES ('518', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 160 از shipped به completed تغییر کرد', '1', '0', '160', '2025-07-30 11:50:43', '2025-07-30 11:50:53');
INSERT INTO `notifications` VALUES ('519', 'other', 'پیام جدید از تماس با ما', 'پیام جدید از Hoseiin با موضوع 123', '1', '1', '3', '2025-07-30 12:49:49', '2025-07-31 11:49:34');
INSERT INTO `notifications` VALUES ('520', 'other', 'پیام جدید از تماس با ما', 'پیام جدید از Hoseiin با موضوع 123', '1', '1', '4', '2025-07-30 12:50:30', '2025-07-30 20:45:13');
INSERT INTO `notifications` VALUES ('521', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '1', '161', '2025-07-30 18:56:39', '2025-07-31 11:49:34');
INSERT INTO `notifications` VALUES ('522', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '0', '162', '2025-07-31 16:57:05', '2025-07-31 17:00:33');
INSERT INTO `notifications` VALUES ('523', 'new_message', 'پیام جدید در مشاوره', 'پیام جدید در مشاوره با موضوع dv', '1', '1', '5', '2025-07-31 17:04:18', '2025-07-31 17:05:11');
INSERT INTO `notifications` VALUES ('524', 'new_order', 'سفارش جدید', 'سفارش جدید از کاربر Hoseiin Mirzaii در سبد خرید ثبت شد', '1', '1', '163', '2025-07-31 17:05:25', '2025-07-31 17:36:50');
INSERT INTO `notifications` VALUES ('525', '', 'تغییر وضعیت سفارش', 'وضعیت سفارش شماره 163 از pending به processing تغییر کرد', '1', '1', '163', '2025-07-31 17:05:39', '2025-07-31 17:36:50');
INSERT INTO `notifications` VALUES ('526', 'new_order', 'پرداخت موفق', 'پرداخت سفارش شماره 163 توسط کاربر Hoseiin Mirzaii با مبلغ 4560000 انجام شد', '1', '1', '163', '2025-07-31 17:05:39', '2025-07-31 17:36:50');

--
-- Table structure for table `orderdetails`
--
DROP TABLE IF EXISTS `orderdetails`;
CREATE TABLE `orderdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` decimal(12,0) NOT NULL,
  `subtotal` decimal(12,0) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `orderdetails_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `orderdetails_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=395 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderdetails`
--
INSERT INTO `orderdetails` VALUES ('342', '141', '15', '1', '2200000', '2200000', '2025-07-22 20:11:15');
INSERT INTO `orderdetails` VALUES ('343', '141', '14', '1', '1800000', '1800000', '2025-07-22 20:11:15');
INSERT INTO `orderdetails` VALUES ('344', '142', '11', '2', '3500000', '7000000', '2025-07-22 20:11:58');
INSERT INTO `orderdetails` VALUES ('345', '142', '26', '1', '3500000', '3500000', '2025-07-22 20:11:59');
INSERT INTO `orderdetails` VALUES ('349', '143', '15', '1', '2200000', '2200000', '2025-07-22 20:39:54');
INSERT INTO `orderdetails` VALUES ('351', '145', '15', '1', '2200000', '2200000', '2025-07-22 20:54:59');
INSERT INTO `orderdetails` VALUES ('352', '146', '13', '1', '1500000', '1500000', '2025-07-22 20:57:03');
INSERT INTO `orderdetails` VALUES ('356', '148', '13', '1', '1500000', '1500000', '2025-07-22 21:22:23');
INSERT INTO `orderdetails` VALUES ('357', '148', '11', '1', '3500000', '3500000', '2025-07-22 21:22:23');
INSERT INTO `orderdetails` VALUES ('370', '149', '15', '1', '2200000', '2200000', '2025-07-22 21:41:11');
INSERT INTO `orderdetails` VALUES ('371', '149', '11', '1', '3500000', '3500000', '2025-07-22 21:43:32');
INSERT INTO `orderdetails` VALUES ('374', '151', '11', '1', '3500000', '3500000', '2025-07-22 22:21:02');
INSERT INTO `orderdetails` VALUES ('377', '153', '6', '3', '3500000', '10500000', '2025-07-24 17:27:32');
INSERT INTO `orderdetails` VALUES ('378', '154', '6', '3', '3500000', '10500000', '2025-07-24 17:28:18');
INSERT INTO `orderdetails` VALUES ('379', '155', '46', '1', '2000000', '2000000', '2025-07-25 10:01:14');
INSERT INTO `orderdetails` VALUES ('382', '156', '26', '1', '3500000', '3500000', '2025-07-25 12:22:58');
INSERT INTO `orderdetails` VALUES ('383', '156', '14', '1', '1800000', '1800000', '2025-07-25 12:22:59');
INSERT INTO `orderdetails` VALUES ('384', '157', '13', '10', '1500000', '15000000', '2025-07-26 19:55:31');
INSERT INTO `orderdetails` VALUES ('386', '158', '26', '1', '3500000', '3500000', '2025-07-27 19:29:38');
INSERT INTO `orderdetails` VALUES ('388', '160', '46', '1', '2000000', '2000000', '2025-07-28 12:39:25');
INSERT INTO `orderdetails` VALUES ('393', '163', '15', '1', '2200000', '2200000', '2025-07-31 17:05:25');
INSERT INTO `orderdetails` VALUES ('394', '163', '11', '1', '3500000', '3500000', '2025-07-31 17:05:26');

--
-- Table structure for table `orders`
--
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `total_price` decimal(12,0) NOT NULL,
  `status` enum('pending','processing','shipped','completed','cancelled') DEFAULT 'pending',
  `payment_status` enum('paid','unpaid') DEFAULT 'unpaid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--
INSERT INTO `orders` VALUES ('141', '21', '3200000', 'completed', 'paid', '2025-07-22 20:11:15', '2025-07-22 20:11:39');
INSERT INTO `orders` VALUES ('142', '21', '21500000', 'completed', 'paid', '2025-07-22 20:11:58', '2025-07-22 20:43:15');
INSERT INTO `orders` VALUES ('143', '21', '1760000', 'completed', 'paid', '2025-07-22 20:39:54', '2025-07-22 20:43:16');
INSERT INTO `orders` VALUES ('145', '21', '1760000', 'completed', 'paid', '2025-07-22 20:54:59', '2025-07-22 20:55:40');
INSERT INTO `orders` VALUES ('146', '21', '1200000', 'completed', 'paid', '2025-07-22 20:57:03', '2025-07-22 20:58:13');
INSERT INTO `orders` VALUES ('148', '21', '4000000', 'completed', 'paid', '2025-07-22 21:03:36', '2025-07-22 22:00:51');
INSERT INTO `orders` VALUES ('149', '21', '4560000', 'completed', 'paid', '2025-07-22 21:23:03', '2025-07-22 22:00:52');
INSERT INTO `orders` VALUES ('151', '21', '2800000', 'completed', 'paid', '2025-07-22 22:21:02', '2025-07-22 22:43:05');
INSERT INTO `orders` VALUES ('153', '21', '10500000', 'completed', 'paid', '2025-07-24 17:26:43', '2025-07-24 17:29:29');
INSERT INTO `orders` VALUES ('154', '21', '10500000', 'completed', 'paid', '2025-07-24 17:28:18', '2025-07-24 17:29:38');
INSERT INTO `orders` VALUES ('155', '21', '1600000', 'completed', 'paid', '2025-07-25 10:01:14', '2025-07-26 19:56:13');
INSERT INTO `orders` VALUES ('156', '21', '4240000', 'completed', 'paid', '2025-07-25 10:05:08', '2025-07-26 19:56:16');
INSERT INTO `orders` VALUES ('157', '21', '12000000', 'completed', 'paid', '2025-07-26 19:55:31', '2025-07-28 10:20:28');
INSERT INTO `orders` VALUES ('158', '21', '2800000', 'completed', 'paid', '2025-07-27 18:38:13', '2025-07-28 13:28:33');
INSERT INTO `orders` VALUES ('160', '21', '1600000', 'completed', 'paid', '2025-07-28 12:39:25', '2025-07-30 11:50:43');
INSERT INTO `orders` VALUES ('163', '21', '4560000', 'processing', 'paid', '2025-07-31 17:05:25', '2025-07-31 17:05:39');

--
-- Table structure for table `payments`
--
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(12,0) NOT NULL,
  `payment_method` enum('online','cash_on_delivery') DEFAULT 'online',
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('successful','failed') DEFAULT 'successful',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--
INSERT INTO `payments` VALUES ('98', '141', '21', '3200000', 'online', '2025-07-22 20:11:24', 'successful');
INSERT INTO `payments` VALUES ('100', '142', '21', '21500000', 'online', '2025-07-22 20:14:40', 'successful');
INSERT INTO `payments` VALUES ('101', '143', '21', '1760000', 'online', '2025-07-22 20:40:03', 'successful');
INSERT INTO `payments` VALUES ('103', '145', '21', '1760000', 'online', '2025-07-22 20:55:05', 'successful');
INSERT INTO `payments` VALUES ('104', '146', '21', '1200000', 'online', '2025-07-22 20:57:10', 'successful');
INSERT INTO `payments` VALUES ('107', '148', '21', '4000000', 'online', '2025-07-22 21:22:53', 'successful');
INSERT INTO `payments` VALUES ('109', '149', '21', '1760000', 'online', '2025-07-22 21:38:06', 'successful');
INSERT INTO `payments` VALUES ('110', '149', '21', '1760000', 'online', '2025-07-22 21:41:24', 'successful');
INSERT INTO `payments` VALUES ('111', '149', '21', '4560000', 'online', '2025-07-22 21:50:38', 'successful');
INSERT INTO `payments` VALUES ('113', '151', '21', '2800000', 'online', '2025-07-22 22:21:10', 'successful');
INSERT INTO `payments` VALUES ('114', '153', '21', '10500000', 'online', '2025-07-24 17:27:58', 'successful');
INSERT INTO `payments` VALUES ('115', '154', '21', '10500000', 'online', '2025-07-24 17:28:27', 'successful');
INSERT INTO `payments` VALUES ('116', '155', '21', '1600000', 'online', '2025-07-25 10:01:27', 'successful');
INSERT INTO `payments` VALUES ('117', '156', '21', '4240000', 'online', '2025-07-25 12:23:12', 'successful');
INSERT INTO `payments` VALUES ('118', '157', '21', '12000000', 'online', '2025-07-26 19:55:41', 'successful');
INSERT INTO `payments` VALUES ('119', '158', '21', '2800000', 'online', '2025-07-27 19:33:47', 'successful');
INSERT INTO `payments` VALUES ('120', '160', '21', '1600000', 'online', '2025-07-28 12:41:50', 'successful');
INSERT INTO `payments` VALUES ('121', '163', '21', '4560000', 'online', '2025-07-31 17:05:39', 'successful');

--
-- Table structure for table `productattributes`
--
DROP TABLE IF EXISTS `productattributes`;
CREATE TABLE `productattributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `attribute_name` varchar(255) NOT NULL,
  `attribute_value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `productattributes_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=360 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productattributes`
--
INSERT INTO `productattributes` VALUES ('1', '1', 'پردازنده', 'Snapdragon 8 Gen 2');
INSERT INTO `productattributes` VALUES ('2', '1', 'RAM', '12GB');
INSERT INTO `productattributes` VALUES ('3', '1', 'حافظه داخلی', '256GB');
INSERT INTO `productattributes` VALUES ('4', '1', 'صفحه نمایش', '6.8 اینچ Dynamic AMOLED 2X');
INSERT INTO `productattributes` VALUES ('5', '1', 'دوربین اصلی', '200MP + 12MP + 10MP + 10MP');
INSERT INTO `productattributes` VALUES ('6', '1', 'دوربین سلفی', '12MP');
INSERT INTO `productattributes` VALUES ('7', '1', 'باتری', '5000mAh');
INSERT INTO `productattributes` VALUES ('8', '1', 'سیستم عامل', 'Android 13');
INSERT INTO `productattributes` VALUES ('9', '1', 'رنگ‌ها', 'مشکی، سبز، بنفش، بژ');
INSERT INTO `productattributes` VALUES ('10', '2', 'پردازنده', 'MediaTek Dimensity 1080');
INSERT INTO `productattributes` VALUES ('11', '2', 'RAM', '8GB');
INSERT INTO `productattributes` VALUES ('12', '2', 'حافظه داخلی', '128GB');
INSERT INTO `productattributes` VALUES ('13', '2', 'صفحه نمایش', '6.67 اینچ AMOLED 120Hz');
INSERT INTO `productattributes` VALUES ('14', '2', 'دوربین اصلی', '50MP + 8MP + 2MP');
INSERT INTO `productattributes` VALUES ('15', '2', 'دوربین سلفی', '16MP');
INSERT INTO `productattributes` VALUES ('16', '2', 'باتری', '5000mAh با شارژ 67W');
INSERT INTO `productattributes` VALUES ('17', '2', 'سیستم عامل', 'Android 12');
INSERT INTO `productattributes` VALUES ('18', '2', 'رنگ‌ها', 'آبی، مشکی، سفید');
INSERT INTO `productattributes` VALUES ('19', '3', 'پردازنده', 'A16 Bionic');
INSERT INTO `productattributes` VALUES ('20', '3', 'RAM', '6GB');
INSERT INTO `productattributes` VALUES ('21', '3', 'حافظه داخلی', '256GB');
INSERT INTO `productattributes` VALUES ('22', '3', 'صفحه نمایش', '6.7 اینچ Super Retina XDR');
INSERT INTO `productattributes` VALUES ('23', '3', 'دوربین اصلی', '48MP + 12MP + 12MP');
INSERT INTO `productattributes` VALUES ('24', '3', 'دوربین سلفی', '12MP');
INSERT INTO `productattributes` VALUES ('25', '3', 'باتری', '4323mAh');
INSERT INTO `productattributes` VALUES ('26', '3', 'سیستم عامل', 'iOS 16');
INSERT INTO `productattributes` VALUES ('27', '3', 'رنگ‌ها', 'بنفش، طلایی، نقره‌ای، مشکی');
INSERT INTO `productattributes` VALUES ('28', '4', 'پردازنده', 'Snapdragon 8+ Gen 1');
INSERT INTO `productattributes` VALUES ('29', '4', 'RAM', '8GB');
INSERT INTO `productattributes` VALUES ('30', '4', 'حافظه داخلی', '256GB');
INSERT INTO `productattributes` VALUES ('31', '4', 'صفحه نمایش', '6.67 اینچ OLED 120Hz');
INSERT INTO `productattributes` VALUES ('32', '4', 'دوربین اصلی', '48MP + 13MP + 48MP');
INSERT INTO `productattributes` VALUES ('33', '4', 'دوربین سلفی', '13MP');
INSERT INTO `productattributes` VALUES ('34', '4', 'باتری', '4815mAh با شارژ 88W');
INSERT INTO `productattributes` VALUES ('35', '4', 'سیستم عامل', 'HarmonyOS 3');
INSERT INTO `productattributes` VALUES ('36', '4', 'رنگ‌ها', 'مشکی، سبز، بنفش');
INSERT INTO `productattributes` VALUES ('46', '6', 'پردازنده', 'Intel Core i7-11800H');
INSERT INTO `productattributes` VALUES ('47', '6', 'RAM', '16GB DDR4');
INSERT INTO `productattributes` VALUES ('48', '6', 'حافظه', '512GB SSD');
INSERT INTO `productattributes` VALUES ('49', '6', 'کارت گرافیک', 'NVIDIA RTX 3050');
INSERT INTO `productattributes` VALUES ('50', '6', 'صفحه نمایش', '15.6 اینچ IPS 144Hz');
INSERT INTO `productattributes` VALUES ('51', '6', 'سیستم عامل', 'Windows 11');
INSERT INTO `productattributes` VALUES ('52', '6', 'وزن', '2.2 کیلوگرم');
INSERT INTO `productattributes` VALUES ('53', '6', 'پورت‌ها', 'USB 3.2, HDMI, Thunderbolt 4');
INSERT INTO `productattributes` VALUES ('54', '7', 'پردازنده', 'AMD Ryzen 7 6800H');
INSERT INTO `productattributes` VALUES ('55', '7', 'RAM', '16GB DDR5');
INSERT INTO `productattributes` VALUES ('56', '7', 'حافظه', '1TB SSD');
INSERT INTO `productattributes` VALUES ('57', '7', 'کارت گرافیک', 'NVIDIA RTX 3060');
INSERT INTO `productattributes` VALUES ('58', '7', 'صفحه نمایش', '15.6 اینچ IPS 165Hz');
INSERT INTO `productattributes` VALUES ('59', '7', 'سیستم عامل', 'Windows 11');
INSERT INTO `productattributes` VALUES ('60', '7', 'وزن', '2.4 کیلوگرم');
INSERT INTO `productattributes` VALUES ('61', '7', 'پورت‌ها', 'USB-C, HDMI, USB 3.2');
INSERT INTO `productattributes` VALUES ('62', '8', 'پردازنده', 'Apple M2 Pro');
INSERT INTO `productattributes` VALUES ('63', '8', 'RAM', '16GB unified');
INSERT INTO `productattributes` VALUES ('64', '8', 'حافظه', '512GB SSD');
INSERT INTO `productattributes` VALUES ('65', '8', 'کارت گرافیک', '19-core GPU');
INSERT INTO `productattributes` VALUES ('66', '8', 'صفحه نمایش', '14.2 اینچ Liquid Retina XDR');
INSERT INTO `productattributes` VALUES ('67', '8', 'سیستم عامل', 'macOS Ventura');
INSERT INTO `productattributes` VALUES ('68', '8', 'وزن', '1.6 کیلوگرم');
INSERT INTO `productattributes` VALUES ('69', '8', 'پورت‌ها', 'Thunderbolt 4, HDMI, MagSafe');
INSERT INTO `productattributes` VALUES ('70', '9', 'پردازنده', 'Intel Core i7-1260P');
INSERT INTO `productattributes` VALUES ('71', '9', 'RAM', '16GB LPDDR5');
INSERT INTO `productattributes` VALUES ('72', '9', 'حافظه', '1TB SSD');
INSERT INTO `productattributes` VALUES ('73', '9', 'کارت گرافیک', 'Intel Iris Xe');
INSERT INTO `productattributes` VALUES ('74', '9', 'صفحه نمایش', '14 اینچ OLED 2.8K');
INSERT INTO `productattributes` VALUES ('75', '9', 'سیستم عامل', 'Windows 11');
INSERT INTO `productattributes` VALUES ('76', '9', 'وزن', '1.39 کیلوگرم');
INSERT INTO `productattributes` VALUES ('77', '9', 'باتری', '75Wh تا 15 ساعت کارکرد');
INSERT INTO `productattributes` VALUES ('78', '10', 'پردازنده', 'Intel Core i9-13900K');
INSERT INTO `productattributes` VALUES ('79', '10', 'RAM', '32GB DDR5');
INSERT INTO `productattributes` VALUES ('80', '10', 'حافظه', '1TB SSD + 2TB HDD');
INSERT INTO `productattributes` VALUES ('81', '10', 'کارت گرافیک', 'NVIDIA RTX 4080');
INSERT INTO `productattributes` VALUES ('82', '10', 'منبع تغذیه', '850W 80+ Gold');
INSERT INTO `productattributes` VALUES ('83', '10', 'سیستم عامل', 'Windows 11 Pro');
INSERT INTO `productattributes` VALUES ('84', '10', 'کیس', 'ROG Strix Helios');
INSERT INTO `productattributes` VALUES ('85', '11', 'صفحه نمایش', '14.6 اینچ Super AMOLED 120Hz');
INSERT INTO `productattributes` VALUES ('86', '11', 'پردازنده', 'Snapdragon 8 Gen 1');
INSERT INTO `productattributes` VALUES ('87', '11', 'RAM', '12GB');
INSERT INTO `productattributes` VALUES ('88', '11', 'حافظه', '256GB');
INSERT INTO `productattributes` VALUES ('89', '11', 'دوربین اصلی', '13MP + 6MP');
INSERT INTO `productattributes` VALUES ('90', '11', 'دوربین سلفی', '12MP');
INSERT INTO `productattributes` VALUES ('91', '11', 'باتری', '11200mAh');
INSERT INTO `productattributes` VALUES ('92', '11', 'سیستم عامل', 'Android 12');
INSERT INTO `productattributes` VALUES ('93', '11', 'قلم S Pen', 'دارد');
INSERT INTO `productattributes` VALUES ('94', '12', 'صفحه نمایش', '12.9 اینچ Liquid Retina XDR');
INSERT INTO `productattributes` VALUES ('95', '12', 'پردازنده', 'Apple M2');
INSERT INTO `productattributes` VALUES ('96', '12', 'RAM', '8GB');
INSERT INTO `productattributes` VALUES ('97', '12', 'حافظه', '256GB');
INSERT INTO `productattributes` VALUES ('98', '12', 'دوربین اصلی', '12MP');
INSERT INTO `productattributes` VALUES ('99', '12', 'دوربین سلفی', '12MP');
INSERT INTO `productattributes` VALUES ('100', '12', 'باتری', 'تا 10 ساعت کارکرد');
INSERT INTO `productattributes` VALUES ('101', '12', 'سیستم عامل', 'iPadOS 16');
INSERT INTO `productattributes` VALUES ('102', '12', 'پشتیبانی از Apple Pencil', 'نسخه 2');
INSERT INTO `productattributes` VALUES ('103', '13', 'صفحه نمایش', '11.5 اینچ OLED 2K');
INSERT INTO `productattributes` VALUES ('104', '13', 'پردازنده', 'Snapdragon 730G');
INSERT INTO `productattributes` VALUES ('105', '13', 'RAM', '6GB');
INSERT INTO `productattributes` VALUES ('106', '13', 'حافظه', '128GB');
INSERT INTO `productattributes` VALUES ('107', '13', 'دوربین اصلی', '13MP');
INSERT INTO `productattributes` VALUES ('108', '13', 'دوربین سلفی', '8MP');
INSERT INTO `productattributes` VALUES ('109', '13', 'باتری', '8600mAh');
INSERT INTO `productattributes` VALUES ('110', '13', 'سیستم عامل', 'Android 11');
INSERT INTO `productattributes` VALUES ('111', '13', 'قلم اختصاصی', 'اختیاری');
INSERT INTO `productattributes` VALUES ('112', '14', 'صفحه نمایش', '11 اینچ IPS LCD 144Hz');
INSERT INTO `productattributes` VALUES ('113', '14', 'پردازنده', 'Snapdragon 870');
INSERT INTO `productattributes` VALUES ('114', '14', 'RAM', '8GB');
INSERT INTO `productattributes` VALUES ('115', '14', 'حافظه', '256GB');
INSERT INTO `productattributes` VALUES ('116', '14', 'دوربین اصلی', '13MP');
INSERT INTO `productattributes` VALUES ('117', '14', 'دوربین سلفی', '8MP');
INSERT INTO `productattributes` VALUES ('118', '14', 'باتری', '8840mAh با شارژ 33W');
INSERT INTO `productattributes` VALUES ('119', '14', 'سیستم عامل', 'Android 13');
INSERT INTO `productattributes` VALUES ('120', '14', 'بلندگو', 'چهار بلندگو');
INSERT INTO `productattributes` VALUES ('121', '15', 'صفحه نمایش', '12.6 اینچ OLED 120Hz');
INSERT INTO `productattributes` VALUES ('122', '15', 'پردازنده', 'Kirin 9000E');
INSERT INTO `productattributes` VALUES ('123', '15', 'RAM', '8GB');
INSERT INTO `productattributes` VALUES ('124', '15', 'حافظه', '256GB');
INSERT INTO `productattributes` VALUES ('125', '15', 'دوربین اصلی', '13MP + 8MP + 3D');
INSERT INTO `productattributes` VALUES ('126', '15', 'دوربین سلفی', '8MP');
INSERT INTO `productattributes` VALUES ('127', '15', 'باتری', '10050mAh با شارژ 40W');
INSERT INTO `productattributes` VALUES ('128', '15', 'سیستم عامل', 'HarmonyOS 3');
INSERT INTO `productattributes` VALUES ('129', '15', 'قلم هوشمند', 'HUAWEI M-Pencil');
INSERT INTO `productattributes` VALUES ('130', '16', 'ظرفیت', '20000mAh');
INSERT INTO `productattributes` VALUES ('131', '16', 'ورودی', 'USB-C, Micro USB');
INSERT INTO `productattributes` VALUES ('132', '16', 'خروجی', 'دو پورت USB-A');
INSERT INTO `productattributes` VALUES ('133', '16', 'قدرت خروجی', '18W');
INSERT INTO `productattributes` VALUES ('134', '16', 'وزن', '350 گرم');
INSERT INTO `productattributes` VALUES ('135', '16', 'جنس بدنه', 'پلاستیک مقاوم');
INSERT INTO `productattributes` VALUES ('136', '17', 'جنس', 'چرم طبیعی');
INSERT INTO `productattributes` VALUES ('137', '17', 'رنگ', 'مشکی');
INSERT INTO `productattributes` VALUES ('138', '17', 'سازگاری', 'گلکسی S23');
INSERT INTO `productattributes` VALUES ('139', '17', 'ویژگی', 'محافظت از دوربین');
INSERT INTO `productattributes` VALUES ('140', '17', 'مناسب برای', 'کارت و پول');
INSERT INTO `productattributes` VALUES ('141', '18', 'جنس', 'سیلیکون مرغوب');
INSERT INTO `productattributes` VALUES ('142', '18', 'رنگ', 'مشکی، آبی، صورتی');
INSERT INTO `productattributes` VALUES ('143', '18', 'سازگاری', 'آیفون 14');
INSERT INTO `productattributes` VALUES ('144', '18', 'ضد لغزش', 'بله');
INSERT INTO `productattributes` VALUES ('145', '18', 'ضد خش', 'بله');
INSERT INTO `productattributes` VALUES ('146', '19', 'توان خروجی', '65W');
INSERT INTO `productattributes` VALUES ('147', '19', 'پورت‌ها', 'USB-C, USB-A');
INSERT INTO `productattributes` VALUES ('148', '19', 'فناوری شارژ', 'PD 3.0, QC 3.0');
INSERT INTO `productattributes` VALUES ('149', '19', 'سیم', 'جدا شدنی');
INSERT INTO `productattributes` VALUES ('150', '19', 'وزن', '120 گرم');
INSERT INTO `productattributes` VALUES ('151', '20', 'جنس', 'آلومینیوم و پلاستیک');
INSERT INTO `productattributes` VALUES ('152', '20', 'قابلیت تنظیم ارتفاع', 'دارد');
INSERT INTO `productattributes` VALUES ('153', '20', 'قابلیت چرخش', '360 درجه');
INSERT INTO `productattributes` VALUES ('154', '20', 'حداکثر اندازه موبایل', '7 اینچ');
INSERT INTO `productattributes` VALUES ('155', '20', 'وزن', '250 گرم');
INSERT INTO `productattributes` VALUES ('156', '21', 'نوع', 'بی‌سیم');
INSERT INTO `productattributes` VALUES ('157', '21', 'فناوری اتصال', 'بلوتوث 5.3');
INSERT INTO `productattributes` VALUES ('158', '21', 'میکروفون', 'دارد');
INSERT INTO `productattributes` VALUES ('159', '21', 'نویزکنسلینگ', 'فعال');
INSERT INTO `productattributes` VALUES ('160', '21', 'مقاومت در برابر آب', 'IPX7');
INSERT INTO `productattributes` VALUES ('161', '21', 'مدت زمان باتری', 'تا 29 ساعت با کیس');
INSERT INTO `productattributes` VALUES ('162', '21', 'رنگ‌ها', 'سفید، مشکی، بنفش');
INSERT INTO `productattributes` VALUES ('163', '22', 'نوع', 'بی‌سیم');
INSERT INTO `productattributes` VALUES ('164', '22', 'فناوری اتصال', 'بلوتوث 5.3');
INSERT INTO `productattributes` VALUES ('165', '22', 'میکروفون', 'دارد');
INSERT INTO `productattributes` VALUES ('166', '22', 'نویزکنسلینگ', 'فعال');
INSERT INTO `productattributes` VALUES ('167', '22', 'مقاومت در برابر آب', 'IPX4');
INSERT INTO `productattributes` VALUES ('168', '22', 'مدت زمان باتری', 'تا 30 ساعت با کیس');
INSERT INTO `productattributes` VALUES ('169', '22', 'سازگاری', 'بهینه برای دستگاه‌های اپل');
INSERT INTO `productattributes` VALUES ('170', '23', 'نوع', 'با سیم');
INSERT INTO `productattributes` VALUES ('171', '23', 'طول کابل', '2.1 متر');
INSERT INTO `productattributes` VALUES ('172', '23', 'میکروفون', 'جداشدنی');
INSERT INTO `productattributes` VALUES ('173', '23', 'نویزکنسلینگ', 'دارد');
INSERT INTO `productattributes` VALUES ('174', '23', 'سازگاری', 'PC, PS4, Xbox, موبایل');
INSERT INTO `productattributes` VALUES ('175', '23', 'رنگ', 'مشکی');
INSERT INTO `productattributes` VALUES ('176', '23', 'وزن', '280 گرم');
INSERT INTO `productattributes` VALUES ('177', '24', 'نوع', 'بی‌سیم');
INSERT INTO `productattributes` VALUES ('178', '24', 'فناوری اتصال', 'بلوتوث 5.2');
INSERT INTO `productattributes` VALUES ('179', '24', 'میکروفون', 'دارد');
INSERT INTO `productattributes` VALUES ('180', '24', 'مدت زمان باتری', '36 ساعت با کیس');
INSERT INTO `productattributes` VALUES ('181', '24', 'شارژ سریع', '5 دقیقه شارژ = 1 ساعت استفاده');
INSERT INTO `productattributes` VALUES ('182', '24', 'رنگ‌ها', 'سفید، مشکی، آبی');
INSERT INTO `productattributes` VALUES ('183', '25', 'نوع', 'بی‌سیم');
INSERT INTO `productattributes` VALUES ('184', '25', 'فناوری اتصال', 'بلوتوث 5.2');
INSERT INTO `productattributes` VALUES ('185', '25', 'نویزکنسلینگ', 'پیشرفته');
INSERT INTO `productattributes` VALUES ('186', '25', 'مدت زمان باتری', '30 ساعت');
INSERT INTO `productattributes` VALUES ('187', '25', 'وزن', '250 گرم');
INSERT INTO `productattributes` VALUES ('188', '25', 'پورت شارژ', 'USB-C');
INSERT INTO `productattributes` VALUES ('189', '25', 'رنگ', 'مشکی، نقره‌ای');
INSERT INTO `productattributes` VALUES ('190', '26', 'نوع صفحه نمایش', 'QLED 4K');
INSERT INTO `productattributes` VALUES ('191', '26', 'اندازه', '55 اینچ');
INSERT INTO `productattributes` VALUES ('192', '26', 'رزولوشن', '3840 x 2160');
INSERT INTO `productattributes` VALUES ('193', '26', 'نرخ نوسازی', '120Hz');
INSERT INTO `productattributes` VALUES ('194', '26', 'سیستم عامل', 'Tizen');
INSERT INTO `productattributes` VALUES ('195', '26', 'پورت‌ها', '4x HDMI, 2x USB, Ethernet');
INSERT INTO `productattributes` VALUES ('196', '26', 'فناوری HDR', 'HDR10+, HLG');
INSERT INTO `productattributes` VALUES ('197', '26', 'بلندگو', '2.1 کاناله 40W');
INSERT INTO `productattributes` VALUES ('198', '27', 'نوع صفحه نمایش', 'OLED 4K');
INSERT INTO `productattributes` VALUES ('199', '27', 'اندازه', '65 اینچ');
INSERT INTO `productattributes` VALUES ('200', '27', 'رزولوشن', '3840 x 2160');
INSERT INTO `productattributes` VALUES ('201', '27', 'نرخ نوسازی', '120Hz');
INSERT INTO `productattributes` VALUES ('202', '27', 'سیستم عامل', 'webOS');
INSERT INTO `productattributes` VALUES ('203', '27', 'پورت‌ها', '4x HDMI 2.1, 3x USB');
INSERT INTO `productattributes` VALUES ('204', '27', 'فناوری HDR', 'Dolby Vision, HDR10');
INSERT INTO `productattributes` VALUES ('205', '27', 'صدای دالبی', 'Dolby Atmos');
INSERT INTO `productattributes` VALUES ('206', '28', 'رزولوشن', '1920x1080 Full HD');
INSERT INTO `productattributes` VALUES ('207', '28', 'روشنایی', '1300 ANSI lumens');
INSERT INTO `productattributes` VALUES ('208', '28', 'کنتراست', '1500:1');
INSERT INTO `productattributes` VALUES ('209', '28', 'منبع نور', 'LED');
INSERT INTO `productattributes` VALUES ('210', '28', 'عمر لامپ', '30000 ساعت');
INSERT INTO `productattributes` VALUES ('211', '28', 'سیستم عامل', 'Android TV');
INSERT INTO `productattributes` VALUES ('212', '28', 'پورت‌ها', 'HDMI, USB, Audio Jack');
INSERT INTO `productattributes` VALUES ('213', '29', 'نوع', 'ساندبار با ساب ووفر');
INSERT INTO `productattributes` VALUES ('214', '29', 'توان خروجی', '330W (3.1.2 کاناله)');
INSERT INTO `productattributes` VALUES ('215', '29', 'فناوری صدا', 'Dolby Atmos, DTS:X');
INSERT INTO `productattributes` VALUES ('216', '29', 'اتصال', 'HDMI eARC, بلوتوث، وای‌فای');
INSERT INTO `productattributes` VALUES ('217', '29', 'ویژگی‌ها', 'ساب ووفر بی‌سیم، اکو سیستم');
INSERT INTO `productattributes` VALUES ('218', '29', 'ابعاد', '110 x 6 x 13 cm');
INSERT INTO `productattributes` VALUES ('219', '30', 'نوع صفحه نمایش', 'LED 4K');
INSERT INTO `productattributes` VALUES ('220', '30', 'اندازه', '43 اینچ');
INSERT INTO `productattributes` VALUES ('221', '30', 'رزولوشن', '3840 x 2160');
INSERT INTO `productattributes` VALUES ('222', '30', 'سیستم عامل', 'Android TV');
INSERT INTO `productattributes` VALUES ('223', '30', 'پورت‌ها', '3x HDMI, 2x USB');
INSERT INTO `productattributes` VALUES ('224', '30', 'فناوری HDR', 'HDR10, HLG');
INSERT INTO `productattributes` VALUES ('225', '30', 'بلندگو', '2x 10W');
INSERT INTO `productattributes` VALUES ('226', '31', 'پردازنده', 'AMD Zen 2 8-core');
INSERT INTO `productattributes` VALUES ('227', '31', 'GPU', 'AMD RDNA 2 (10.3 TFLOPS)');
INSERT INTO `productattributes` VALUES ('228', '31', 'حافظه', '825GB SSD');
INSERT INTO `productattributes` VALUES ('229', '31', 'رزولوشن', 'پشتیبانی از 8K');
INSERT INTO `productattributes` VALUES ('230', '31', 'نرخ فریم', 'تا 120fps');
INSERT INTO `productattributes` VALUES ('231', '31', 'کنترلر', 'DualSense Wireless');
INSERT INTO `productattributes` VALUES ('232', '31', 'نوع', 'نسخه دیجیتال (بدون درایو نوری)');
INSERT INTO `productattributes` VALUES ('233', '32', 'پردازنده', 'AMD Zen 2 8-core');
INSERT INTO `productattributes` VALUES ('234', '32', 'GPU', 'AMD RDNA 2 (12 TFLOPS)');
INSERT INTO `productattributes` VALUES ('235', '32', 'حافظه', '1TB SSD');
INSERT INTO `productattributes` VALUES ('236', '32', 'رزولوشن', 'پشتیبانی از 8K');
INSERT INTO `productattributes` VALUES ('237', '32', 'نرخ فریم', 'تا 120fps');
INSERT INTO `productattributes` VALUES ('238', '32', 'کنترلر', 'Xbox Wireless Controller');
INSERT INTO `productattributes` VALUES ('239', '32', 'پشتیبانی', 'Xbox Game Pass');
INSERT INTO `productattributes` VALUES ('240', '33', 'صفحه نمایش', '7 اینچ OLED');
INSERT INTO `productattributes` VALUES ('241', '33', 'رزولوشن', '1280x720 (هندهد), 1920x1080 (داک)');
INSERT INTO `productattributes` VALUES ('242', '33', 'حافظه داخلی', '64GB');
INSERT INTO `productattributes` VALUES ('243', '33', 'باتری', '4.5-9 ساعت بسته به بازی');
INSERT INTO `productattributes` VALUES ('244', '33', 'کنترلر', 'Joy-Con دو عدد');
INSERT INTO `productattributes` VALUES ('245', '33', 'پشتیبانی', 'تمام بازی‌های Nintendo Switch');
INSERT INTO `productattributes` VALUES ('246', '34', 'نوع', 'بی‌سیم');
INSERT INTO `productattributes` VALUES ('247', '34', 'باتری', 'لیتیوم یون (تا 12 ساعت)');
INSERT INTO `productattributes` VALUES ('248', '34', 'اتصال', 'بلوتوث، USB-C');
INSERT INTO `productattributes` VALUES ('249', '34', 'ویژگی‌ها', 'فیدبک لمسی، مقاومت تطبیقی');
INSERT INTO `productattributes` VALUES ('250', '34', 'سازگاری', 'PS5, PC, Android');
INSERT INTO `productattributes` VALUES ('251', '34', 'رنگ', 'سفید');
INSERT INTO `productattributes` VALUES ('252', '35', 'پردازنده', 'AMD Zen 2 4-core/8-thread');
INSERT INTO `productattributes` VALUES ('253', '35', 'GPU', 'AMD RDNA 2 (1.6 TFLOPS)');
INSERT INTO `productattributes` VALUES ('254', '35', 'حافظه', '16GB LPDDR5');
INSERT INTO `productattributes` VALUES ('255', '35', 'ذخیره سازی', '256GB NVMe SSD');
INSERT INTO `productattributes` VALUES ('256', '35', 'صفحه نمایش', '7 اینچ LCD لمسی');
INSERT INTO `productattributes` VALUES ('257', '35', 'سیستم عامل', 'SteamOS 3.0');
INSERT INTO `productattributes` VALUES ('258', '35', 'باتری', '40Whr (2-8 ساعت)');
INSERT INTO `productattributes` VALUES ('259', '36', 'سنسور', 'Full-frame CMOS 24.2MP');
INSERT INTO `productattributes` VALUES ('260', '36', 'پردازشگر تصویر', 'DIGIC X');
INSERT INTO `productattributes` VALUES ('261', '36', 'حساسیت ISO', '100-102400 (قابل گسترش)');
INSERT INTO `productattributes` VALUES ('262', '36', 'فیلمبرداری', '4K 60fps بدون کراپ');
INSERT INTO `productattributes` VALUES ('263', '36', 'فوکوس خودکار', 'Dual Pixel CMOS AF II');
INSERT INTO `productattributes` VALUES ('264', '36', 'صفحه نمایش', '3 اینچ LCD چرخشی لمسی');
INSERT INTO `productattributes` VALUES ('265', '36', 'تثبیت تصویر', '5-axis IBIS تا 8 استاپ');
INSERT INTO `productattributes` VALUES ('266', '37', 'سنسور', 'Full-frame BSI CMOS 33MP');
INSERT INTO `productattributes` VALUES ('267', '37', 'پردازشگر تصویر', 'BIONZ XR');
INSERT INTO `productattributes` VALUES ('268', '37', 'حساسیت ISO', '100-51200 (قابل گسترش)');
INSERT INTO `productattributes` VALUES ('269', '37', 'فیلمبرداری', '4K 30fps (7K oversampling)');
INSERT INTO `productattributes` VALUES ('270', '37', 'فوکوس خودکار', '759-point phase detection');
INSERT INTO `productattributes` VALUES ('271', '37', 'صفحه نمایش', '3 اینچ LCD چرخشی لمسی');
INSERT INTO `productattributes` VALUES ('272', '37', 'تثبیت تصویر', '5-axis IBIS تا 5.5 استاپ');
INSERT INTO `productattributes` VALUES ('273', '38', 'سنسور', 'APS-C X-Trans CMOS 5 HR 40MP');
INSERT INTO `productattributes` VALUES ('274', '38', 'پردازشگر تصویر', 'X-Processor 5');
INSERT INTO `productattributes` VALUES ('275', '38', 'حساسیت ISO', '125-12800 (قابل گسترش)');
INSERT INTO `productattributes` VALUES ('276', '38', 'فیلمبرداری', '6.2K 30p, 4K 60p');
INSERT INTO `productattributes` VALUES ('277', '38', 'فوکوس خودکار', '425-point hybrid AF');
INSERT INTO `productattributes` VALUES ('278', '38', 'صفحه نمایش', '3 اینچ LCD چرخشی');
INSERT INTO `productattributes` VALUES ('279', '38', 'تثبیت تصویر', '5-axis IBIS تا 7 استاپ');
INSERT INTO `productattributes` VALUES ('280', '39', 'فاصله کانونی', '24-70mm');
INSERT INTO `productattributes` VALUES ('281', '39', 'دیافراگم', 'f/2.8 ثابت');
INSERT INTO `productattributes` VALUES ('282', '39', 'فرمت', 'Full-frame');
INSERT INTO `productattributes` VALUES ('283', '39', 'ساختار اپتیکی', '15 گروه، 21 عنصر');
INSERT INTO `productattributes` VALUES ('284', '39', 'تثبیت تصویر', 'دارد (5 استاپ)');
INSERT INTO `productattributes` VALUES ('285', '39', 'فیلتر', '82mm');
INSERT INTO `productattributes` VALUES ('286', '39', 'وزن', '900 گرم');
INSERT INTO `productattributes` VALUES ('287', '40', 'جنس', 'آلومینیوم');
INSERT INTO `productattributes` VALUES ('288', '40', 'حداکثر ارتفاع', '142cm');
INSERT INTO `productattributes` VALUES ('289', '40', 'حداقل ارتفاع', '40cm');
INSERT INTO `productattributes` VALUES ('290', '40', 'وزن', '1.4kg');
INSERT INTO `productattributes` VALUES ('291', '40', 'ظرفیت بار', '4kg');
INSERT INTO `productattributes` VALUES ('292', '40', 'سر سه‌پایه', 'توپی 360 درجه');
INSERT INTO `productattributes` VALUES ('293', '40', 'تا شدن', '16cm');
INSERT INTO `productattributes` VALUES ('294', '41', 'صفحه نمایش', 'IPS LCD');
INSERT INTO `productattributes` VALUES ('295', '41', 'اندازه', '27 اینچ');
INSERT INTO `productattributes` VALUES ('296', '41', 'رزولوشن', '2560x1440 (QHD)');
INSERT INTO `productattributes` VALUES ('297', '41', 'نرخ نوسازی', '144Hz');
INSERT INTO `productattributes` VALUES ('298', '41', 'زمان پاسخگویی', '1ms');
INSERT INTO `productattributes` VALUES ('299', '41', 'پورت‌ها', 'DisplayPort 1.2, HDMI 2.0');
INSERT INTO `productattributes` VALUES ('300', '41', 'ویژگی‌ها', 'FreeSync Premium, HDR10');
INSERT INTO `productattributes` VALUES ('301', '42', 'نوع سوئیچ', 'Razer Green (مکانیکی)');
INSERT INTO `productattributes` VALUES ('302', '42', 'نورپردازی', 'RGB Chroma');
INSERT INTO `productattributes` VALUES ('303', '42', 'اتصال', 'USB');
INSERT INTO `productattributes` VALUES ('304', '42', 'ویژگی‌ها', 'ضد آب، کلیدهای ماکرو');
INSERT INTO `productattributes` VALUES ('305', '42', 'کلیدهای میانبر', 'دارد');
INSERT INTO `productattributes` VALUES ('306', '42', 'وزن', '1.2kg');
INSERT INTO `productattributes` VALUES ('307', '43', 'نوع', 'بی‌سیم');
INSERT INTO `productattributes` VALUES ('308', '43', 'حسگر', 'Darkfield 4000 DPI');
INSERT INTO `productattributes` VALUES ('309', '43', 'باتری', 'لیتیوم یون (تا 70 روز)');
INSERT INTO `productattributes` VALUES ('310', '43', 'اتصال', 'Bluetooth, USB Unifying');
INSERT INTO `productattributes` VALUES ('311', '43', 'ویژگی‌ها', 'اسکرول هوشمند، 7 دکمه');
INSERT INTO `productattributes` VALUES ('312', '43', 'سازگاری', 'ویندوز، مک، لینوکس');
INSERT INTO `productattributes` VALUES ('313', '44', 'ظرفیت', '2TB');
INSERT INTO `productattributes` VALUES ('314', '44', 'نوع', 'HDD');
INSERT INTO `productattributes` VALUES ('315', '44', 'سرعت', '5400 RPM');
INSERT INTO `productattributes` VALUES ('316', '44', 'اتصال', 'USB 3.0');
INSERT INTO `productattributes` VALUES ('317', '44', 'ابعاد', '11.5 x 8 x 2 cm');
INSERT INTO `productattributes` VALUES ('318', '44', 'وزن', '170 گرم');
INSERT INTO `productattributes` VALUES ('319', '44', 'مقاومت', 'ضد ضربه');
INSERT INTO `productattributes` VALUES ('320', '45', 'پورت‌ها', '3x Thunderbolt 4, HDMI, USB-A');
INSERT INTO `productattributes` VALUES ('321', '45', 'پشتیبانی از نمایشگر', 'دو مانیتور 4K یا یک مانیتور 8K');
INSERT INTO `productattributes` VALUES ('322', '45', 'کارت خوان', 'SDXC UHS-II');
INSERT INTO `productattributes` VALUES ('323', '45', 'اتصال شبکه', 'گیگابیت اترنت');
INSERT INTO `productattributes` VALUES ('324', '45', 'توان خروجی', '96W برای شارژ لپتاپ');
INSERT INTO `productattributes` VALUES ('325', '45', 'سازگاری', 'مک‌بوک پرو و ایر با تراشه M');
INSERT INTO `productattributes` VALUES ('326', '46', 'اندازه', '41mm یا 45mm');
INSERT INTO `productattributes` VALUES ('327', '46', 'صفحه نمایش', 'Retina LTPO OLED');
INSERT INTO `productattributes` VALUES ('328', '46', 'سنسورها', 'ضربان قلب، ECG، SpO2');
INSERT INTO `productattributes` VALUES ('329', '46', 'مقاومت در برابر آب', '50 متر');
INSERT INTO `productattributes` VALUES ('330', '46', 'باتری', 'تا 18 ساعت');
INSERT INTO `productattributes` VALUES ('331', '46', 'ویژگی‌ها', 'ردیابی خواب، تشخیص افتادن');
INSERT INTO `productattributes` VALUES ('332', '46', 'سازگاری', 'آیفون با iOS 16+');
INSERT INTO `productattributes` VALUES ('333', '47', 'صفحه نمایش', '1.62 اینچ AMOLED');
INSERT INTO `productattributes` VALUES ('334', '47', 'سنسورها', 'ضربان قلب، SpO2');
INSERT INTO `productattributes` VALUES ('335', '47', 'مقاومت در برابر آب', '50 متر');
INSERT INTO `productattributes` VALUES ('336', '47', 'باتری', 'تا 14 روز');
INSERT INTO `productattributes` VALUES ('337', '47', 'ویژگی‌ها', 'ردیابی 120 فعالیت ورزشی');
INSERT INTO `productattributes` VALUES ('338', '47', 'وزن', '13.5 گرم');
INSERT INTO `productattributes` VALUES ('339', '47', 'سازگاری', 'اندروید 6.0+, iOS 10+');
INSERT INTO `productattributes` VALUES ('340', '48', 'اندازه', '40mm یا 44mm');
INSERT INTO `productattributes` VALUES ('341', '48', 'صفحه نمایش', 'Super AMOLED');
INSERT INTO `productattributes` VALUES ('342', '48', 'سنسورها', 'ضربان قلب، ECG، فشار خون');
INSERT INTO `productattributes` VALUES ('343', '48', 'مقاومت در برابر آب', '50 متر');
INSERT INTO `productattributes` VALUES ('344', '48', 'باتری', 'تا 50 ساعت');
INSERT INTO `productattributes` VALUES ('345', '48', 'سیستم عامل', 'Wear OS (سامسونگ)');
INSERT INTO `productattributes` VALUES ('346', '48', 'سازگاری', 'اندروید 8.0+');
INSERT INTO `productattributes` VALUES ('347', '49', 'نوع', 'چراغ RGB هوشمند');
INSERT INTO `productattributes` VALUES ('348', '49', 'توان', '9.5W (معادل 60W معمولی)');
INSERT INTO `productattributes` VALUES ('349', '49', 'رنگ‌ها', '16 میلیون رنگ');
INSERT INTO `productattributes` VALUES ('350', '49', 'اتصال', 'Zigbee (نیاز به Bridge)');
INSERT INTO `productattributes` VALUES ('351', '49', 'سازگاری', 'Google Assistant, Alexa, HomeKit');
INSERT INTO `productattributes` VALUES ('352', '49', 'عمر مفید', '25000 ساعت');
INSERT INTO `productattributes` VALUES ('353', '50', 'صفحه نمایش', '7 اینچ LCD لمسی');
INSERT INTO `productattributes` VALUES ('354', '50', 'دوربین', 'دارد (با دریچه حریم خصوصی)');
INSERT INTO `productattributes` VALUES ('355', '50', 'بلندگو', 'فول رنج');
INSERT INTO `productattributes` VALUES ('356', '50', 'دستیار صوتی', 'Google Assistant');
INSERT INTO `productattributes` VALUES ('357', '50', 'اتصال', 'وای‌فای، بلوتوث');
INSERT INTO `productattributes` VALUES ('358', '50', 'ویژگی‌ها', 'کنترل خانه هوشمند، تماس تصویری');
INSERT INTO `productattributes` VALUES ('359', '4', 'رنگ بندی', 'زرد، قرمز، ابی و مشکی');

--
-- Table structure for table `productcomparison`
--
DROP TABLE IF EXISTS `productcomparison`;
CREATE TABLE `productcomparison` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `productcomparison_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `productcomparison_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `productimages`
--
DROP TABLE IF EXISTS `productimages`;
CREATE TABLE `productimages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `productimages_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productimages`
--
INSERT INTO `productimages` VALUES ('1', '32', '../image/products-images/ایکسباکس_سری_X/img_686aaa4ce2e904.73613560.webp', '2025-07-06 20:24:36');
INSERT INTO `productimages` VALUES ('2', '32', '../image/products-images/ایکسباکس_سری_X/img_686aaa4ce3a218.19578991.jpeg', '2025-07-06 20:24:36');
INSERT INTO `productimages` VALUES ('3', '32', '../image/products-images/ایکسباکس_سری_X/img_686aaa4ce43a98.06947723.webp', '2025-07-06 20:24:36');
INSERT INTO `productimages` VALUES ('4', '12', '../image/products-images/تبلت_اپل_آیپد_پرو_129_اینچ/img_686aaa7b25cfc1.39960636.webp', '2025-07-06 20:25:23');
INSERT INTO `productimages` VALUES ('5', '12', '../image/products-images/تبلت_اپل_آیپد_پرو_129_اینچ/img_686aaa7b26b701.34112593.webp', '2025-07-06 20:25:23');
INSERT INTO `productimages` VALUES ('6', '12', '../image/products-images/تبلت_اپل_آیپد_پرو_129_اینچ/img_686aaa7b27d802.32826957.webp', '2025-07-06 20:25:23');
INSERT INTO `productimages` VALUES ('7', '11', '../image/products-images/تبلت_سامسونگ_گلکسی_تب_S8_Ultra/img_686aaab534be38.99290442.webp', '2025-07-06 20:26:21');
INSERT INTO `productimages` VALUES ('8', '11', '../image/products-images/تبلت_سامسونگ_گلکسی_تب_S8_Ultra/img_686aaab5356a54.62422179.webp', '2025-07-06 20:26:21');
INSERT INTO `productimages` VALUES ('10', '11', '../image/products-images/تبلت_سامسونگ_گلکسی_تب_S8_Ultra/img_686aaab5375a63.45339509.webp', '2025-07-06 20:26:21');
INSERT INTO `productimages` VALUES ('15', '14', '../image/products-images/تبلت_شیائومی_Pad_6/img_686aaaea2ec6a2.55180345.webp', '2025-07-06 20:27:14');
INSERT INTO `productimages` VALUES ('16', '14', '../image/products-images/تبلت_شیائومی_Pad_6/img_686aaaea2f8ed3.87235798.webp', '2025-07-06 20:27:14');
INSERT INTO `productimages` VALUES ('17', '14', '../image/products-images/تبلت_شیائومی_Pad_6/img_686aaaea303a64.65897256.webp', '2025-07-06 20:27:14');
INSERT INTO `productimages` VALUES ('23', '13', '../image/products-images/تبلت_لنوو_P11_Pro/img_686aab67b322e9.79945755.webp', '2025-07-06 20:29:19');
INSERT INTO `productimages` VALUES ('24', '13', '../image/products-images/تبلت_لنوو_P11_Pro/img_686aab67b436f6.94325941.webp', '2025-07-06 20:29:19');
INSERT INTO `productimages` VALUES ('26', '13', '../image/products-images/تبلت_لنوو_P11_Pro/img_686aab67b61ad2.51521268.webp', '2025-07-06 20:29:19');
INSERT INTO `productimages` VALUES ('28', '15', '../image/products-images/تبلت_هوآوی_MatePad_Pro/img_686aab76658117.61520236.webp', '2025-07-06 20:29:34');
INSERT INTO `productimages` VALUES ('29', '15', '../image/products-images/تبلت_هوآوی_MatePad_Pro/img_686aab7666c667.77698342.webp', '2025-07-06 20:29:34');
INSERT INTO `productimages` VALUES ('30', '15', '../image/products-images/تبلت_هوآوی_MatePad_Pro/img_686aab7667c302.97839438.webp', '2025-07-06 20:29:34');
INSERT INTO `productimages` VALUES ('32', '27', '../image/products-images/تلویزیون_الجی_OLED_65_اینچ/img_686aab87d1a112.77512175.webp', '2025-07-06 20:29:51');
INSERT INTO `productimages` VALUES ('33', '27', '../image/products-images/تلویزیون_الجی_OLED_65_اینچ/img_686aab87d2f016.51446728.webp', '2025-07-06 20:29:51');
INSERT INTO `productimages` VALUES ('34', '27', '../image/products-images/تلویزیون_الجی_OLED_65_اینچ/img_686aab87d3d7d7.61879708.webp', '2025-07-06 20:29:51');
INSERT INTO `productimages` VALUES ('35', '26', '../image/products-images/تلویزیون_هوشمند_سامسونگ_QLED_55_اینچ/img_686aabab6f0e60.28959758.webp', '2025-07-06 20:30:27');
INSERT INTO `productimages` VALUES ('37', '26', '../image/products-images/تلویزیون_هوشمند_سامسونگ_QLED_55_اینچ/img_686aabab7111e0.73658034.webp', '2025-07-06 20:30:27');
INSERT INTO `productimages` VALUES ('38', '26', '../image/products-images/تلویزیون_هوشمند_سامسونگ_QLED_55_اینچ/img_686aabab71a906.31206058.webp', '2025-07-06 20:30:27');
INSERT INTO `productimages` VALUES ('39', '30', '../image/products-images/تلویزیون_هوشیائومی_4K_43_اینچ/img_686aabb952b542.73836693.webp', '2025-07-06 20:30:41');
INSERT INTO `productimages` VALUES ('40', '30', '../image/products-images/تلویزیون_هوشیائومی_4K_43_اینچ/img_686aabb95376f7.17007563.webp', '2025-07-06 20:30:41');
INSERT INTO `productimages` VALUES ('41', '30', '../image/products-images/تلویزیون_هوشیائومی_4K_43_اینچ/img_686aabb9544b26.38183486.webp', '2025-07-06 20:30:41');
INSERT INTO `productimages` VALUES ('43', '45', '../image/products-images/داک_استیشن_تاندربولت_اپل/img_686aabcaa92fb0.42223068.webp', '2025-07-06 20:30:58');
INSERT INTO `productimages` VALUES ('44', '45', '../image/products-images/داک_استیشن_تاندربولت_اپل/img_686aabcaaa0086.61761078.webp', '2025-07-06 20:30:58');
INSERT INTO `productimages` VALUES ('45', '45', '../image/products-images/داک_استیشن_تاندربولت_اپل/img_686aabcaaab122.30750985.webp', '2025-07-06 20:30:58');
INSERT INTO `productimages` VALUES ('47', '47', '../image/products-images/دستبند_هوشمند_شیائومی_Band_7/img_686aabefc2c246.39150916.webp', '2025-07-06 20:31:35');
INSERT INTO `productimages` VALUES ('49', '47', '../image/products-images/دستبند_هوشمند_شیائومی_Band_7/img_686aabefc454c6.69787143.webp', '2025-07-06 20:31:35');
INSERT INTO `productimages` VALUES ('50', '47', '../image/products-images/دستبند_هوشمند_شیائومی_Band_7/img_686aabefc55499.96069858.webp', '2025-07-06 20:31:35');
INSERT INTO `productimages` VALUES ('51', '34', '../image/products-images/دسته_پلیاستیشن_DualSense/img_686aac03cc9316.29818593.webp', '2025-07-06 20:31:55');
INSERT INTO `productimages` VALUES ('53', '34', '../image/products-images/دسته_پلیاستیشن_DualSense/img_686aac03ced688.09371380.webp', '2025-07-06 20:31:55');
INSERT INTO `productimages` VALUES ('54', '34', '../image/products-images/دسته_پلیاستیشن_DualSense/img_686aac03cf8e46.28613829.webp', '2025-07-06 20:31:55');
INSERT INTO `productimages` VALUES ('56', '50', '../image/products-images/دستگاه_هوشمند_Google_Nest_Hub/img_686aac1a5ae588.72452243.webp', '2025-07-06 20:32:18');
INSERT INTO `productimages` VALUES ('57', '50', '../image/products-images/دستگاه_هوشمند_Google_Nest_Hub/img_686aac1a5b8ac5.88957084.webp', '2025-07-06 20:32:18');
INSERT INTO `productimages` VALUES ('58', '50', '../image/products-images/دستگاه_هوشمند_Google_Nest_Hub/img_686aac1a5c1d58.90176040.webp', '2025-07-06 20:32:18');
INSERT INTO `productimages` VALUES ('59', '37', '../image/products-images/دوربین_سونی_A7_IV/img_686aac29e2e107.49901671.webp', '2025-07-06 20:32:33');
INSERT INTO `productimages` VALUES ('60', '37', '../image/products-images/دوربین_سونی_A7_IV/img_686aac29e3ca33.90570941.webp', '2025-07-06 20:32:33');
INSERT INTO `productimages` VALUES ('62', '37', '../image/products-images/دوربین_سونی_A7_IV/img_686aac29e542e4.76098217.webp', '2025-07-06 20:32:33');
INSERT INTO `productimages` VALUES ('64', '38', '../image/products-images/دوربین_فوجی_فیلم_X-T5/img_686aac3992f1a4.88462365.webp', '2025-07-06 20:32:49');
INSERT INTO `productimages` VALUES ('65', '38', '../image/products-images/دوربین_فوجی_فیلم_X-T5/img_686aac3993f4c4.51716065.webp', '2025-07-06 20:32:49');
INSERT INTO `productimages` VALUES ('66', '38', '../image/products-images/دوربین_فوجی_فیلم_X-T5/img_686aac39957086.44308141.webp', '2025-07-06 20:32:49');
INSERT INTO `productimages` VALUES ('67', '36', '../image/products-images/دوربین_کانن_EOS_R6_Mark_II/img_686aac4b9fdf41.08190634.webp', '2025-07-06 20:33:07');
INSERT INTO `productimages` VALUES ('69', '36', '../image/products-images/دوربین_کانن_EOS_R6_Mark_II/img_686aac4ba127d3.33262202.webp', '2025-07-06 20:33:07');
INSERT INTO `productimages` VALUES ('70', '36', '../image/products-images/دوربین_کانن_EOS_R6_Mark_II/img_686aac4ba229e7.04871752.webp', '2025-07-06 20:33:07');
INSERT INTO `productimages` VALUES ('71', '48', '../image/products-images/ساعت_سامسونگ_گلکسی_واچ_5/img_686aac58997e65.49800488.webp', '2025-07-06 20:33:20');
INSERT INTO `productimages` VALUES ('72', '48', '../image/products-images/ساعت_سامسونگ_گلکسی_واچ_5/img_686aac589a5727.72841636.webp', '2025-07-06 20:33:20');
INSERT INTO `productimages` VALUES ('74', '48', '../image/products-images/ساعت_سامسونگ_گلکسی_واچ_5/img_686aac589c5f73.54452631.webp', '2025-07-06 20:33:20');
INSERT INTO `productimages` VALUES ('75', '46', '../image/products-images/ساعت_هوشمند_اپل_واچ_سری_8/img_686aac689627c7.19178922.webp', '2025-07-06 20:33:36');
INSERT INTO `productimages` VALUES ('76', '46', '../image/products-images/ساعت_هوشمند_اپل_واچ_سری_8/img_686aac68973673.27210192.webp', '2025-07-06 20:33:36');
INSERT INTO `productimages` VALUES ('77', '46', '../image/products-images/ساعت_هوشمند_اپل_واچ_سری_8/img_686aac6897e3e5.00142770.webp', '2025-07-06 20:33:36');
INSERT INTO `productimages` VALUES ('79', '40', '../image/products-images/سهپایه_مانفروتو_Befree/img_686aac7bba9ca9.98157788.webp', '2025-07-06 20:33:55');
INSERT INTO `productimages` VALUES ('80', '40', '../image/products-images/سهپایه_مانفروتو_Befree/img_686aac7bbb4da0.56660755.webp', '2025-07-06 20:33:55');
INSERT INTO `productimages` VALUES ('82', '40', '../image/products-images/سهپایه_مانفروتو_Befree/img_686aac7bbc8222.53805260.webp', '2025-07-06 20:33:55');
INSERT INTO `productimages` VALUES ('84', '29', '../image/products-images/سینمای_خانگی_سامسونگ_HW-Q800A/img_686aac8b8d4ea6.31628936.webp', '2025-07-06 20:34:11');
INSERT INTO `productimages` VALUES ('85', '29', '../image/products-images/سینمای_خانگی_سامسونگ_HW-Q800A/img_686aac8b8df909.07663249.webp', '2025-07-06 20:34:11');
INSERT INTO `productimages` VALUES ('86', '29', '../image/products-images/سینمای_خانگی_سامسونگ_HW-Q800A/img_686aac8b8ee280.97237092.webp', '2025-07-06 20:34:11');
INSERT INTO `productimages` VALUES ('88', '19', '../image/products-images/شارژر_فست_شارژ_65W_شیائومی/img_686aaca76cedc0.89302734.webp', '2025-07-06 20:34:39');
INSERT INTO `productimages` VALUES ('89', '19', '../image/products-images/شارژر_فست_شارژ_65W_شیائومی/img_686aaca76da9f3.76116457.webp', '2025-07-06 20:34:39');
INSERT INTO `productimages` VALUES ('90', '19', '../image/products-images/شارژر_فست_شارژ_65W_شیائومی/img_686aaca76e68c3.46275945.webp', '2025-07-06 20:34:39');
INSERT INTO `productimages` VALUES ('91', '39', '../image/products-images/لنز_کانن_RF_24-70mm_f28/img_686aacc489c853.24779329.webp', '2025-07-06 20:35:08');
INSERT INTO `productimages` VALUES ('92', '39', '../image/products-images/لنز_کانن_RF_24-70mm_f28/img_686aacc48a7876.76291782.webp', '2025-07-06 20:35:08');
INSERT INTO `productimages` VALUES ('93', '39', '../image/products-images/لنز_کانن_RF_24-70mm_f28/img_686aacc48bc731.39831245.webp', '2025-07-06 20:35:08');
INSERT INTO `productimages` VALUES ('94', '39', '../image/products-images/لنز_کانن_RF_24-70mm_f28/img_686aacc48c7d87.17611627.webp', '2025-07-06 20:35:08');
INSERT INTO `productimages` VALUES ('95', '6', '../image/products-images/لپتاپ_ایسر_Nitro_5/img_686aacd3750c59.77021083.webp', '2025-07-06 20:35:23');
INSERT INTO `productimages` VALUES ('96', '6', '../image/products-images/لپتاپ_ایسر_Nitro_5/img_686aacd375af63.65268785.webp', '2025-07-06 20:35:23');
INSERT INTO `productimages` VALUES ('97', '6', '../image/products-images/لپتاپ_ایسر_Nitro_5/img_686aacd3764606.20517781.webp', '2025-07-06 20:35:23');
INSERT INTO `productimages` VALUES ('99', '9', '../image/products-images/لپتاپ_ایسوس_ZenBook_14/img_686aace37aaa05.11066826.webp', '2025-07-06 20:35:39');
INSERT INTO `productimages` VALUES ('100', '9', '../image/products-images/لپتاپ_ایسوس_ZenBook_14/img_686aace37b5f97.72884982.webp', '2025-07-06 20:35:39');
INSERT INTO `productimages` VALUES ('102', '9', '../image/products-images/لپتاپ_ایسوس_ZenBook_14/img_686aace37cc7d9.95459345.webp', '2025-07-06 20:35:39');
INSERT INTO `productimages` VALUES ('104', '7', '../image/products-images/لپتاپ_لنوو_Legion_5/img_686aacf528f7b7.92308114.webp', '2025-07-06 20:35:57');
INSERT INTO `productimages` VALUES ('105', '7', '../image/products-images/لپتاپ_لنوو_Legion_5/img_686aacf529a462.64015470.webp', '2025-07-06 20:35:57');
INSERT INTO `productimages` VALUES ('106', '7', '../image/products-images/لپتاپ_لنوو_Legion_5/img_686aacf52aa902.76015252.webp', '2025-07-06 20:35:57');
INSERT INTO `productimages` VALUES ('107', '41', '../image/products-images/مانیتور_گیمینگ_ایسوس_27_اینچ_144Hz/img_686aad0862b7b9.38236678.webp', '2025-07-06 20:36:16');
INSERT INTO `productimages` VALUES ('109', '41', '../image/products-images/مانیتور_گیمینگ_ایسوس_27_اینچ_144Hz/img_686aad08640638.94929687.webp', '2025-07-06 20:36:16');
INSERT INTO `productimages` VALUES ('110', '41', '../image/products-images/مانیتور_گیمینگ_ایسوس_27_اینچ_144Hz/img_686aad08649246.70098300.webp', '2025-07-06 20:36:16');
INSERT INTO `productimages` VALUES ('111', '43', '../image/products-images/ماوس_بیسیم_Logitech_MX_Master_3/img_686aad19ba5436.05638164.webp', '2025-07-06 20:36:33');
INSERT INTO `productimages` VALUES ('113', '43', '../image/products-images/ماوس_بیسیم_Logitech_MX_Master_3/img_686aad19bc8338.11379536.webp', '2025-07-06 20:36:33');
INSERT INTO `productimages` VALUES ('114', '43', '../image/products-images/ماوس_بیسیم_Logitech_MX_Master_3/img_686aad19bd5011.56069428.webp', '2025-07-06 20:36:33');
INSERT INTO `productimages` VALUES ('115', '8', '../image/products-images/مکبوک_پرو_14_اینچ_M2/img_686aad2bf094f4.39367327.webp', '2025-07-06 20:36:51');
INSERT INTO `productimages` VALUES ('116', '8', '../image/products-images/مکبوک_پرو_14_اینچ_M2/img_686aad2bf138e9.23396363.webp', '2025-07-06 20:36:51');
INSERT INTO `productimages` VALUES ('118', '8', '../image/products-images/مکبوک_پرو_14_اینچ_M2/img_686aad2bf28984.14041848.webp', '2025-07-06 20:36:51');
INSERT INTO `productimages` VALUES ('119', '33', '../image/products-images/نینتندو_سوئیچ_OLED/img_686aad3a3a5c20.50314940.webp', '2025-07-06 20:37:06');
INSERT INTO `productimages` VALUES ('121', '33', '../image/products-images/نینتندو_سوئیچ_OLED/img_686aad3a3c0e42.68375011.webp', '2025-07-06 20:37:06');
INSERT INTO `productimages` VALUES ('122', '33', '../image/products-images/نینتندو_سوئیچ_OLED/img_686aad3a3cd414.75246975.webp', '2025-07-06 20:37:06');
INSERT INTO `productimages` VALUES ('123', '44', '../image/products-images/هارد_اکسترنال_سیگیت_2TB/img_686aad464c4736.17168674.webp', '2025-07-06 20:37:18');
INSERT INTO `productimages` VALUES ('125', '44', '../image/products-images/هارد_اکسترنال_سیگیت_2TB/img_686aad464d8323.00814439.webp', '2025-07-06 20:37:18');
INSERT INTO `productimages` VALUES ('126', '44', '../image/products-images/هارد_اکسترنال_سیگیت_2TB/img_686aad464e92f5.53051841.webp', '2025-07-06 20:37:18');
INSERT INTO `productimages` VALUES ('127', '22', '../image/products-images/هدفون_اپل_AirPods_Pro_2/img_686aad5896c0b0.62947467.webp', '2025-07-06 20:37:36');
INSERT INTO `productimages` VALUES ('129', '22', '../image/products-images/هدفون_اپل_AirPods_Pro_2/img_686aad5898fe55.60884702.webp', '2025-07-06 20:37:36');
INSERT INTO `productimages` VALUES ('130', '22', '../image/products-images/هدفون_اپل_AirPods_Pro_2/img_686aad589a8d98.77016596.webp', '2025-07-06 20:37:36');
INSERT INTO `productimages` VALUES ('131', '21', '../image/products-images/هدفون_بیسیم_سامسونگ_Buds_2_Pro/img_686aad65d5e0a8.65888541.webp', '2025-07-06 20:37:49');
INSERT INTO `productimages` VALUES ('132', '21', '../image/products-images/هدفون_بیسیم_سامسونگ_Buds_2_Pro/img_686aad65d6a405.74861788.webp', '2025-07-06 20:37:49');
INSERT INTO `productimages` VALUES ('134', '21', '../image/products-images/هدفون_بیسیم_سامسونگ_Buds_2_Pro/img_686aad65d7cd96.36440118.webp', '2025-07-06 20:37:49');
INSERT INTO `productimages` VALUES ('135', '25', '../image/products-images/هدفون_سونی_WH-1000XM5/img_686aad742da5d7.29739014.webp', '2025-07-06 20:38:04');
INSERT INTO `productimages` VALUES ('136', '25', '../image/products-images/هدفون_سونی_WH-1000XM5/img_686aad742e3b69.25111540.webp', '2025-07-06 20:38:04');
INSERT INTO `productimages` VALUES ('137', '25', '../image/products-images/هدفون_سونی_WH-1000XM5/img_686aad742ed045.75588259.webp', '2025-07-06 20:38:04');
INSERT INTO `productimages` VALUES ('139', '23', '../image/products-images/هدفون_گیمینگ_Razer_BlackShark/img_686aad834cab01.20331945.webp', '2025-07-06 20:38:19');
INSERT INTO `productimages` VALUES ('140', '23', '../image/products-images/هدفون_گیمینگ_Razer_BlackShark/img_686aad834d6eb3.24189814.webp', '2025-07-06 20:38:19');
INSERT INTO `productimages` VALUES ('142', '23', '../image/products-images/هدفون_گیمینگ_Razer_BlackShark/img_686aad834ea536.75982950.webp', '2025-07-06 20:38:19');
INSERT INTO `productimages` VALUES ('143', '24', '../image/products-images/هندزفری_بیسیم_شیائومی_Redmi_Buds_4/img_686aad95bc1136.67294056.webp', '2025-07-06 20:38:37');
INSERT INTO `productimages` VALUES ('144', '24', '../image/products-images/هندزفری_بیسیم_شیائومی_Redmi_Buds_4/img_686aad95bcddc1.73600537.webp', '2025-07-06 20:38:37');
INSERT INTO `productimages` VALUES ('146', '24', '../image/products-images/هندزفری_بیسیم_شیائومی_Redmi_Buds_4/img_686aad95be1212.68542033.webp', '2025-07-06 20:38:37');
INSERT INTO `productimages` VALUES ('147', '16', '../image/products-images/پاوربانک_شیائومی_20000mAh/img_686aada7966637.51893166.webp', '2025-07-06 20:38:55');
INSERT INTO `productimages` VALUES ('148', '16', '../image/products-images/پاوربانک_شیائومی_20000mAh/img_686aada79718d8.33762997.webp', '2025-07-06 20:38:55');
INSERT INTO `productimages` VALUES ('149', '16', '../image/products-images/پاوربانک_شیائومی_20000mAh/img_686aada797a887.89247961.webp', '2025-07-06 20:38:55');
INSERT INTO `productimages` VALUES ('152', '20', '../image/products-images/پایه_نگهدارنده_موبایل/img_686aadb8ddcd78.91528664.webp', '2025-07-06 20:39:12');
INSERT INTO `productimages` VALUES ('153', '20', '../image/products-images/پایه_نگهدارنده_موبایل/img_686aadb8de6c13.36310770.webp', '2025-07-06 20:39:12');
INSERT INTO `productimages` VALUES ('154', '20', '../image/products-images/پایه_نگهدارنده_موبایل/img_686aadb8df2db8.01847049.webp', '2025-07-06 20:39:12');
INSERT INTO `productimages` VALUES ('155', '28', '../image/products-images/پروژکتور_شیائومی_می_پرو_2/img_686aadd3da4358.06139790.webp', '2025-07-06 20:39:39');
INSERT INTO `productimages` VALUES ('156', '28', '../image/products-images/پروژکتور_شیائومی_می_پرو_2/img_686aadd3db0091.12717323.webp', '2025-07-06 20:39:39');
INSERT INTO `productimages` VALUES ('158', '28', '../image/products-images/پروژکتور_شیائومی_می_پرو_2/img_686aadd3dc3913.74403363.webp', '2025-07-06 20:39:39');
INSERT INTO `productimages` VALUES ('159', '31', '../image/products-images/پلیاستیشن_5_دیجیتال/img_686aade19343e6.26539254.webp', '2025-07-06 20:39:53');
INSERT INTO `productimages` VALUES ('161', '31', '../image/products-images/پلیاستیشن_5_دیجیتال/img_686aade1953e25.04096864.webp', '2025-07-06 20:39:53');
INSERT INTO `productimages` VALUES ('162', '31', '../image/products-images/پلیاستیشن_5_دیجیتال/img_686aade195f9a5.43671820.webp', '2025-07-06 20:39:53');
INSERT INTO `productimages` VALUES ('164', '49', '../image/products-images/چراغ_هوشمند_فیلیپس_Hue/img_686aadf42099e3.25365803.webp', '2025-07-06 20:40:12');
INSERT INTO `productimages` VALUES ('165', '49', '../image/products-images/چراغ_هوشمند_فیلیپس_Hue/img_686aadf4213e81.65350157.webp', '2025-07-06 20:40:12');
INSERT INTO `productimages` VALUES ('166', '49', '../image/products-images/چراغ_هوشمند_فیلیپس_Hue/img_686aadf421e546.28418196.webp', '2025-07-06 20:40:12');
INSERT INTO `productimages` VALUES ('167', '10', '../image/products-images/کامپیوتر_رومیزی_ایسوس_ROG/img_686aae0a401874.20977398.webp', '2025-07-06 20:40:34');
INSERT INTO `productimages` VALUES ('169', '10', '../image/products-images/کامپیوتر_رومیزی_ایسوس_ROG/img_686aae0a425ba4.86267653.webp', '2025-07-06 20:40:34');
INSERT INTO `productimages` VALUES ('170', '10', '../image/products-images/کامپیوتر_رومیزی_ایسوس_ROG/img_686aae0a436314.36994830.webp', '2025-07-06 20:40:34');
INSERT INTO `productimages` VALUES ('172', '18', '../image/products-images/کاور_سیلیکونی_آیفون_14/img_686aae17620a79.53092971.webp', '2025-07-06 20:40:47');
INSERT INTO `productimages` VALUES ('173', '18', '../image/products-images/کاور_سیلیکونی_آیفون_14/img_686aae1762b362.05290810.webp', '2025-07-06 20:40:47');
INSERT INTO `productimages` VALUES ('174', '18', '../image/products-images/کاور_سیلیکونی_آیفون_14/img_686aae17636e22.61122782.webp', '2025-07-06 20:40:47');
INSERT INTO `productimages` VALUES ('175', '35', '../image/products-images/کنسول_استیم_دک_Valve/img_686aae255fa802.34349305.webp', '2025-07-06 20:41:01');
INSERT INTO `productimages` VALUES ('176', '35', '../image/products-images/کنسول_استیم_دک_Valve/img_686aae25605c71.46494976.webp', '2025-07-06 20:41:01');
INSERT INTO `productimages` VALUES ('177', '35', '../image/products-images/کنسول_استیم_دک_Valve/img_686aae2560f396.29035089.webp', '2025-07-06 20:41:01');
INSERT INTO `productimages` VALUES ('179', '42', '../image/products-images/کیبورد_مکانیکی_Razer_BlackWidow/img_686aae329ffb74.42537495.webp', '2025-07-06 20:41:14');
INSERT INTO `productimages` VALUES ('180', '42', '../image/products-images/کیبورد_مکانیکی_Razer_BlackWidow/img_686aae32a08546.97717994.webp', '2025-07-06 20:41:14');
INSERT INTO `productimages` VALUES ('181', '42', '../image/products-images/کیبورد_مکانیکی_Razer_BlackWidow/img_686aae32a14363.13347976.webp', '2025-07-06 20:41:14');
INSERT INTO `productimages` VALUES ('183', '17', '../image/products-images/کیف_چرمی_سامسونگ_گلکسی_S23/img_686aae42ed19b6.13271980.webp', '2025-07-06 20:41:30');
INSERT INTO `productimages` VALUES ('184', '17', '../image/products-images/کیف_چرمی_سامسونگ_گلکسی_S23/img_686aae42ee7b96.17641617.webp', '2025-07-06 20:41:30');
INSERT INTO `productimages` VALUES ('186', '17', '../image/products-images/کیف_چرمی_سامسونگ_گلکسی_S23/img_686aae42efe763.11141639.webp', '2025-07-06 20:41:30');
INSERT INTO `productimages` VALUES ('187', '3', '../image/products-images/گوشی_آیفون_14_Pro_Max/img_686aae4f731595.90767184.webp', '2025-07-06 20:41:43');
INSERT INTO `productimages` VALUES ('188', '3', '../image/products-images/گوشی_آیفون_14_Pro_Max/img_686aae4f73b0b6.17167846.webp', '2025-07-06 20:41:43');
INSERT INTO `productimages` VALUES ('190', '3', '../image/products-images/گوشی_آیفون_14_Pro_Max/img_686aae4f74d6d8.96822168.webp', '2025-07-06 20:41:43');
INSERT INTO `productimages` VALUES ('191', '1', '../image/products-images/گوشی_سامسونگ_گلکسی_S23_Ultra/img_686aae608a3149.63449343.webp', '2025-07-06 20:42:00');
INSERT INTO `productimages` VALUES ('192', '1', '../image/products-images/گوشی_سامسونگ_گلکسی_S23_Ultra/img_686aae608ac970.01036539.webp', '2025-07-06 20:42:00');
INSERT INTO `productimages` VALUES ('194', '1', '../image/products-images/گوشی_سامسونگ_گلکسی_S23_Ultra/img_686aae608bf543.04822892.webp', '2025-07-06 20:42:00');
INSERT INTO `productimages` VALUES ('195', '2', '../image/products-images/گوشی_شیائومی_Redmi_Note_12_Pro/img_686aae78d9a589.72430911.webp', '2025-07-06 20:42:24');
INSERT INTO `productimages` VALUES ('196', '2', '../image/products-images/گوشی_شیائومی_Redmi_Note_12_Pro/img_686aae78da9e91.94939355.webp', '2025-07-06 20:42:24');
INSERT INTO `productimages` VALUES ('198', '2', '../image/products-images/گوشی_شیائومی_Redmi_Note_12_Pro/img_686aae78dc0fe7.75360558.webp', '2025-07-06 20:42:24');
INSERT INTO `productimages` VALUES ('199', '4', '../image/products-images/گوشی_هوآوی_P60_Pro/img_686aae8aa07175.64852099.webp', '2025-07-06 20:42:42');
INSERT INTO `productimages` VALUES ('200', '4', '../image/products-images/گوشی_هوآوی_P60_Pro/img_686aae8aa18177.79830231.webp', '2025-07-06 20:42:42');
INSERT INTO `productimages` VALUES ('201', '4', '../image/products-images/گوشی_هوآوی_P60_Pro/img_686aae8aa22911.64931282.webp', '2025-07-06 20:42:42');

--
-- Table structure for table `products`
--
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `description` text DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `image_url` varchar(255) DEFAULT 'image/default-Product.jpg',
  `minimum_stock` int(11) DEFAULT 5,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--
INSERT INTO `products` VALUES ('1', 'گوشی سامسونگ گلکسی S23 Ultra', '1', '4500000.00', 'گوشی پرچمدار سامسونگ با دوربین 200 مگاپیکسل', '52', '../image/products-images/uploads/50eb1e893b6e7811a8a822d5229432a2.webp', '5', '2025-07-05 10:13:21', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('2', 'گوشی شیائومی Redmi Note 12 Pro', '1', '1200000.00', 'گوشی میان‌رده با صفحه نمایش AMOLED 120Hz', '22', '../image/products-images/uploads/5074dddbe3d11070473ce5a337b20e00.webp', '5', '2025-07-05 10:13:21', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('3', 'گوشی آیفون 14 Pro Max', '1', '6000000.00', 'پرچمدار اپل با تراشه A16 و دوربین 48 مگاپیکسل', '80', '../image/products-images/uploads/df58c5d3404e302d490eb4c81cc0ca6e.jpeg', '5', '2025-07-05 10:13:21', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('4', 'گوشی هوآوی P60 Pro', '1', '3500000.00', 'گوشی هوآوی با دوربین فوق‌العاده و طراحی لوکس', '39', '../image/products-images/uploads/9c8a2a9ab076dc184a309d2cdbeea777.webp', '5', '2025-07-05 10:13:21', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('6', 'لپتاپ ایسر Nitro 5', '2', '3500000.00', 'لپتاپ گیمینگ با پردازنده Core i7 و کارت گرافیک RTX 3050', '59', '../image/products-images/uploads/d053caca523b633e3584269711e7a7fb.webp', '5', '2025-07-05 10:13:30', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('7', 'لپتاپ لنوو Legion 5', '2', '4200000.00', 'لپتاپ گیمینگ با پردازنده AMD Ryzen 7 و RTX 3060', '43', '../image/products-images/uploads/3fd22bef101de5569330d8ddf51e3ab6.webp', '5', '2025-07-05 10:13:30', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('8', 'مک‌بوک پرو 14 اینچ M2', '2', '6500000.00', 'لپتاپ اپل با تراشه M2 و صفحه نمایش XDR', '40', '../image/products-images/uploads/3e7e48ae8879bfbd3d0bab7b68862939.webp', '5', '2025-07-05 10:13:30', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('9', 'لپتاپ ایسوس ZenBook 14', '2', '2800000.00', 'لپتاپ فوق سبک و باریک با صفحه نمایش OLED', '50', '../image/products-images/uploads/fd281768038cce460330e73e7b934a45.webp', '5', '2025-07-05 10:13:30', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('10', 'کامپیوتر رومیزی ایسوس ROG', '2', '5500000.00', 'کامپیوتر گیمینگ با پردازنده Core i9 و RTX 4080', '30', '../image/products-images/uploads/826d79608bfef11549da0cfc4a654bd7.webp', '5', '2025-07-05 10:13:30', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('11', 'تبلت سامسونگ گلکسی تب S8 Ultra', '3', '3500000.00', 'تبلت بزرگ 14.6 اینچی با قلم S Pen', '45', '../image/products-images/uploads/9f3e20827560a42d7a53abd243d43696.webp', '5', '2025-07-05 10:13:39', '2025-07-31 17:05:39');
INSERT INTO `products` VALUES ('12', 'تبلت اپل آیپد پرو 12.9 اینچ', '3', '4000000.00', 'تبلت اپل با تراشه M2 و صفحه نمایش مینی LED', '78', '../image/products-images/uploads/63770284044778e252925c67dbc755ae.webp', '5', '2025-07-05 10:13:39', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('13', 'تبلت لنوو P11 Pro', '3', '1500000.00', 'تبلت اندرویدی با صفحه نمایش 2K OLED', '31', '../image/products-images/uploads/7536633bd3f4f0e5eea12d86ce3521f7.webp', '5', '2025-07-05 10:13:39', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('14', 'تبلت شیائومی Pad 6', '3', '1800000.00', 'تبلت قدرتمند با پردازنده Snapdragon 870', '38', '../image/products-images/uploads/8942e6e7bce2193ab1a94f1d797490de.jpeg', '5', '2025-07-05 10:13:39', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('15', 'تبلت هوآوی MatePad Pro', '3', '2200000.00', 'تبلت هوآوی با صفحه نمایش 120Hz و قلم هوشمند', '77', '../image/products-images/uploads/7f0c060415e8894a37830462314a4ad6.webp', '5', '2025-07-05 10:13:39', '2025-07-31 17:05:39');
INSERT INTO `products` VALUES ('16', 'پاوربانک شیائومی 20000mAh', '4', '150000.00', 'پاوربانک پرظرفیت با فست شارژ 18W', '50', '../image/products-images/uploads/e4602460ffaebe1f52578f703e4999a9.webp', '5', '2025-07-05 10:13:48', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('17', 'کیف چرمی سامسونگ گلکسی S23', '4', '80000.00', 'کیف چرم اورجینال برای گلکسی S23', '45', '../image/products-images/uploads/0a947424f57903a96c15c2de4d1fc3ae.webp', '5', '2025-07-05 10:13:48', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('18', 'کاور سیلیکونی آیفون 14', '4', '60000.00', 'کاور محافظ ضدضربه برای آیفون 14', '47', '../image/products-images/uploads/2ad7a728249cade18624371e582a81e2.webp', '5', '2025-07-05 10:13:48', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('19', 'شارژر فست شارژ 65W شیائومی', '4', '120000.00', 'شارژر سریع با قابلیت شارژ چند دستگاه', '38', '../image/products-images/uploads/e6f8924c4348d5b9ce33d0f5cfe6ea85.webp', '5', '2025-07-05 10:13:48', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('20', 'پایه نگهدارنده موبایل', '4', '30000.00', 'پایه تنظیم ارتفاع با قابلیت چرخش 360 درجه', '29', '../image/products-images/uploads/5cea83c4c996dd0ac73adf2624f105d9.webp', '5', '2025-07-05 10:13:48', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('21', 'هدفون بی‌سیم سامسونگ Buds 2 Pro', '5', '600000.00', 'هدفون بی‌سیم با نویزکنسلینگ فعال و صدای 24bit', '48', '../image/products-images/uploads/ded6334d53f2680e5900795c172f5159.webp', '5', '2025-07-05 10:14:18', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('22', 'هدفون اپل AirPods Pro 2', '5', '800000.00', 'هدفون بی‌سیم اپل با نویزکنسلینگ و کیفیت صدای عالی', '40', '../image/products-images/uploads/345a6f99ef8dc012f5ba0a18029163cc.webp', '5', '2025-07-05 10:14:18', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('23', 'هدفون گیمینگ Razer BlackShark', '5', '450000.00', 'هدفون حرفه‌ای گیمینگ با میکروفون جداشدنی', '80', '../image/products-images/uploads/9303096143bcbade7a8296b83ebe7bde.webp', '5', '2025-07-05 10:14:18', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('24', 'هندزفری بی‌سیم شیائومی Redmi Buds 4', '5', '180000.00', 'هندزفری با باتری 36 ساعت و حالت شفاف', '25', '../image/products-images/uploads/d3cf22960ac950b735bca0714697acad.webp', '5', '2025-07-05 10:14:18', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('25', 'هدفون سونی WH-1000XM5', '5', '1200000.00', 'بهترین هدفون نویزکنسلینگ بازار با کیفیت صدای عالی', '60', '../image/products-images/uploads/cd7729a73a6664e733d56d7cd566c149.webp', '5', '2025-07-05 10:14:18', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('26', 'تلویزیون هوشمند سامسونگ QLED 55 اینچ', '6', '3500000.00', 'تلویزیون 4K QLED با سیستم عامل تایزن', '33', '../image/products-images/uploads/0e89df2ebf9fa53d7a0f718a2abba2f8.webp', '5', '2025-07-05 10:14:29', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('27', 'تلویزیون ال‌جی OLED 65 اینچ', '6', '6000000.00', 'تلویزیون OLED با کیفیت HDR و صدای دالبی اتمس', '38', '../image/products-images/uploads/507c18ec4ba33cabe57f46ca167e8d90.webp', '5', '2025-07-05 10:14:29', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('28', 'پروژکتور شیائومی می پرو 2', '6', '1500000.00', 'پروژکتور فول اچ‌دی با روشنایی 1300 انسی لومن', '80', '../image/products-images/uploads/b3b07a9ca67593ff39309c265267634f.webp', '5', '2025-07-05 10:14:29', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('29', 'سینمای خانگی سامسونگ HW-Q800A', '6', '1800000.00', 'ساندبار با سیستم صدای دالبی اتمس و ساب ووفر', '60', '../image/products-images/uploads/e48c771495abe16ae0c789b8b486b9e7.webp', '5', '2025-07-05 10:14:29', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('30', 'تلویزیون هوشیائومی 4K 43 اینچ', '6', '1200000.00', 'تلویزیون اقتصادی با صفحه نمایش 4K HDR', '48', '../image/products-images/uploads/ecc07160d3b617fa1623e61d6c31025e.webp', '5', '2025-07-05 10:14:29', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('31', 'پلی‌استیشن 5 دیجیتال', '7', '2500000.00', 'کنسول نسل نهم سونی با هارد 825 گیگابایت', '30', '../image/products-images/uploads/84887b37f7bfd5daa5dfa99f3e54e114.webp', '5', '2025-07-05 10:14:39', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('32', 'ایکس‌باکس سری X', '7', '2800000.00', 'کنسول مایکروسافت با قدرت 12 ترافلاپس', '38', '../image/products-images/uploads/6f938ae335c2c491bac2c3a928496981.jpg', '5', '2025-07-05 10:14:39', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('33', 'نینتندو سوئیچ OLED', '7', '1500000.00', 'نسخه OLED کنسول دستی نینتندو', '80', '../image/products-images/uploads/f90e4aaaf45fef5c6984638033162050.webp', '5', '2025-07-05 10:14:39', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('34', 'دسته پلی‌استیشن DualSense', '7', '250000.00', 'دسته بی‌سیم نسل جدید پلی‌استیشن 5', '39', '../image/products-images/uploads/5f864d2111c1dc46d00dfda566c6d97d.webp', '5', '2025-07-05 10:14:39', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('35', 'کنسول استیم دک Valve', '7', '2000000.00', 'کنسول دستی برای بازی‌های استیم', '49', '../image/products-images/uploads/40ddb0aac8aba2f7de02876a3ef71063.webp', '5', '2025-07-05 10:14:39', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('36', 'دوربین کانن EOS R6 Mark II', '8', '8000000.00', 'دوربین فول‌فریم حرفه‌ای با فیلمبرداری 4K', '22', '../image/products-images/uploads/35ea255bf7b85b3a998a0554a2763b11.webp', '5', '2025-07-05 10:14:50', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('37', 'دوربین سونی A7 IV', '8', '9000000.00', 'دوربین میرورلس فول‌فریم با سنسور 33 مگاپیکسل', '52', '../image/products-images/uploads/2b271a65479185e7326d93a56e70638e.webp', '5', '2025-07-05 10:14:50', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('38', 'دوربین فوجی فیلم X-T5', '8', '6000000.00', 'دوربین APS-C با سنسور 40 مگاپیکسل', '40', '../image/products-images/uploads/623f6c47f91a9c87e5eaf94ebe4fc0ad.webp', '5', '2025-07-05 10:14:50', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('39', 'لنز کانن RF 24-70mm f/2.8', '8', '5000000.00', 'لنز استاندارد حرفه‌ای سری RF', '30', '../image/products-images/uploads/57b189e19bc3f0de6f6c65a9d816be11.webp', '5', '2025-07-05 10:14:50', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('40', 'سه‌پایه مانفروتو Befree', '8', '800000.00', 'سه‌پایه سبک و قابل حمل برای عکاسان', '30', '../image/products-images/uploads/671b172de2a23f072a75af44190e0e35.webp', '5', '2025-07-05 10:14:50', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('41', 'مانیتور گیمینگ ایسوس 27 اینچ 144Hz', '9', '1500000.00', 'مانیتور با نرخ نوسازی 144Hz و زمان پاسخگویی 1ms', '68', '../image/products-images/uploads/d169ef0e969dc09b244c50d4ff277060.webp', '5', '2025-07-05 10:15:06', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('42', 'کیبورد مکانیکی Razer BlackWidow', '9', '600000.00', 'کیبورد گیمینگ با سوئیچ‌های مکانیکی', '29', '../image/products-images/uploads/a16e5c9809835c0724c209b864449bf3.webp', '5', '2025-07-05 10:15:06', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('43', 'ماوس بی‌سیم Logitech MX Master 3', '9', '400000.00', 'ماوس حرفه‌ای با قابلیت شارژ و اسکرول هوشمند', '36', '../image/products-images/uploads/77687657a5386c435a49047345f93c80.webp', '5', '2025-07-05 10:15:06', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('44', 'هارد اکسترنال سیگیت 2TB', '9', '300000.00', 'هارد پرتابل با سرعت بالا و مقاوم در برابر ضربه', '47', '../image/products-images/uploads/d3e82b77545b6b8fa2b100661a82db1d.webp', '5', '2025-07-05 10:15:06', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('45', 'داک استیشن تاندربولت اپل', '9', '1000000.00', 'داک استیشن حرفه‌ای با پورت‌های متعدد', '46', '../image/products-images/uploads/8a989f0e18d446dd39be34550390fe3d.webp', '5', '2025-07-05 10:15:06', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('46', 'ساعت هوشمند اپل واچ سری 8', '10', '2000000.00', 'ساعت هوشمند با صفحه نمایش همیشه روشن و سنسور ECG', '52', '../image/products-images/uploads/6089988a6d5ed222d6a813de975c9cfe.webp', '5', '2025-07-05 10:15:16', '2025-07-28 12:41:50');
INSERT INTO `products` VALUES ('47', 'دستبند هوشمند شیائومی Band 7', '10', '200000.00', 'دستبند با صفحه نمایش AMOLED و باتری 14 روزه', '47', '../image/products-images/uploads/268bd3dfcdd831ca2f9dcc5f9eaef115.webp', '5', '2025-07-05 10:15:16', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('48', 'ساعت سامسونگ گلکسی واچ 5', '10', '1500000.00', 'ساعت هوشمند با سیستم عامل Wear OS', '46', '../image/products-images/uploads/f336863be3ae1a27c554cc379d8940b4.webp', '5', '2025-07-05 10:15:16', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('49', 'چراغ هوشمند فیلیپس Hue', '10', '300000.00', 'چراغ RGB هوشمند با قابلیت کنترل از راه دور', '35', '../image/products-images/uploads/6105bdd1c24b2d4c0e788bd8ebea1bb6.webp', '5', '2025-07-05 10:15:16', '2025-07-28 11:39:24');
INSERT INTO `products` VALUES ('50', 'دستگاه هوشمند Google Nest Hub', '10', '800000.00', 'دستگاه کنترل خانه هوشمند با صفحه نمایش 7 اینچ', '53', '../image/products-images/uploads/74ca63e73cea65426a03e49c115e9826.webp', '5', '2025-07-05 10:15:16', '2025-07-28 11:39:24');

--
-- Table structure for table `productviews`
--
DROP TABLE IF EXISTS `productviews`;
CREATE TABLE `productviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `view_date` date NOT NULL,
  `view_count` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_daily_view` (`product_id`,`ip_address`,`view_date`),
  KEY `product_id` (`product_id`),
  KEY `ip_address` (`ip_address`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2536 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productviews`
--
INSERT INTO `productviews` VALUES ('2522', '12', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-28', '1', '2025-07-28 10:06:09', '2025-07-28 10:06:09');
INSERT INTO `productviews` VALUES ('2523', '14', '22', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', '2025-07-28', '1', '2025-07-28 10:06:27', '2025-07-28 10:06:27');
INSERT INTO `productviews` VALUES ('2524', '11', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-28', '1', '2025-07-28 12:26:35', '2025-07-28 12:26:35');
INSERT INTO `productviews` VALUES ('2525', '42', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-28', '1', '2025-07-28 18:10:00', '2025-07-28 18:10:00');
INSERT INTO `productviews` VALUES ('2526', '26', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-28', '1', '2025-07-28 18:34:03', '2025-07-28 18:34:03');
INSERT INTO `productviews` VALUES ('2527', '15', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-28', '1', '2025-07-28 18:49:39', '2025-07-28 18:49:39');
INSERT INTO `productviews` VALUES ('2528', '6', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-31', '1', '2025-07-31 16:57:50', '2025-07-31 16:57:50');
INSERT INTO `productviews` VALUES ('2529', '12', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-31', '1', '2025-07-31 16:58:11', '2025-07-31 16:58:11');
INSERT INTO `productviews` VALUES ('2530', '11', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-31', '1', '2025-07-31 16:58:22', '2025-07-31 16:58:22');
INSERT INTO `productviews` VALUES ('2531', '13', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-31', '1', '2025-07-31 16:58:24', '2025-07-31 16:58:24');
INSERT INTO `productviews` VALUES ('2532', '14', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-31', '1', '2025-07-31 16:58:26', '2025-07-31 16:58:26');
INSERT INTO `productviews` VALUES ('2533', '15', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-31', '1', '2025-07-31 16:58:29', '2025-07-31 16:58:29');
INSERT INTO `productviews` VALUES ('2534', '29', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-31', '1', '2025-07-31 16:58:34', '2025-07-31 16:58:34');
INSERT INTO `productviews` VALUES ('2535', '37', '21', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', '2025-07-31', '1', '2025-07-31 17:07:49', '2025-07-31 17:07:49');

--
-- Table structure for table `reviews`
--
DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `reviews` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Table structure for table `shopsettings`
--
DROP TABLE IF EXISTS `shopsettings`;
CREATE TABLE `shopsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(255) NOT NULL,
  `shop_description` text DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `instagram` varchar(100) DEFAULT NULL,
  `telegram` varchar(100) DEFAULT NULL,
  `whatsapp` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `working_hours` varchar(100) DEFAULT NULL,
  `youtube` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `button_color` varchar(20) DEFAULT '#007bff',
  `font_family` varchar(100) DEFAULT 'Arial, sans-serif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shopsettings`
--
INSERT INTO `shopsettings` VALUES ('1', 'فروشگاه دیجیتالی من', 'سلام خوبی', '../image/logo-shop/logo_6889dd1d4886b.jpg', 'admin@gmail.com', '0123456789', 'https://instagram.com/admin', 'https://t.me/admin', 'https://wa.me/0123456789', 'https://nshn.ir/b5_bvhF-PxOn0s', '9:00 تا 17:00 - پنجشنبه‌ها تعطیل', 'https://youtube.com/admin', 'Tehran', '#4e73df', 'Vazir, sans-serif', '2025-07-09 16:47:03', '2025-07-30 12:41:02');

--
-- Table structure for table `shopsliders`
--
DROP TABLE IF EXISTS `shopsliders`;
CREATE TABLE `shopsliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_url` varchar(255) NOT NULL,
  `caption` text DEFAULT NULL,
  `button_text` varchar(50) DEFAULT NULL,
  `button_link` varchar(255) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shopsliders`
--
INSERT INTO `shopsliders` VALUES ('93', '../image/sliders/slider_686e6d8817396.jpeg', 'فروشگاه دیجیتالی خوش اومدین', 'دیدن محصولات', 'public/products.php', '1', '1', '2025-07-30 12:41:02');
INSERT INTO `shopsliders` VALUES ('94', '../image/sliders/slider_686e6dc2990a4.jpeg', 'فروشگاه دیجیتالی خوش اومدین', 'دیدن محصولات', 'public/products.php', '2', '1', '2025-07-30 12:41:02');
INSERT INTO `shopsliders` VALUES ('95', '../image/sliders/slider_686e6dc2996af.jpeg', 'فروشگاه دیجیتالی خوش اومدین', 'دیدن محصولات', 'public/products.php', '3', '1', '2025-07-30 12:41:02');

--
-- Table structure for table `teammembers`
--
DROP TABLE IF EXISTS `teammembers`;
CREATE TABLE `teammembers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `about_us_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `bio` text DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `instagram_link` varchar(255) DEFAULT NULL,
  `telegram_link` varchar(255) DEFAULT NULL,
  `linkedin_link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `about_us_id` (`about_us_id`),
  CONSTRAINT `teammembers_ibfk_1` FOREIGN KEY (`about_us_id`) REFERENCES `aboutus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teammembers`
--
INSERT INTO `teammembers` VALUES ('1', '1', 'علی رضایی', 'مدیر عامل', 'علی با بیش از 10 سال تجربه در صنعت فناوری اطلاعات، به عنوان مدیر عامل شرکت مشغول به کار است.', '../image/team/member_1753956355_ebe08303.jpg', 'ali@example.com', '09121234567', 'https://instagram.com/alirezai', 'https://t.me/alirezai', 'https://linkedin.com/in/alirezai', '2025-07-31 13:35:16', '2025-07-31 13:35:55');
INSERT INTO `teammembers` VALUES ('2', '1', 'فاطمه محمدی', 'مدیر بازاریابی', 'فاطمه دارای سابقه‌ای درخشان در زمینه بازاریابی دیجیتال و استراتژی‌های فروش است.', '../image/team/member_1753956364_4738fbfd.jpg', 'fatemeh@example.com', '09121234568', 'https://instagram.com/fatemehmohammadi', 'https://t.me/fatemehmohammadi', 'https://linkedin.com/in/fatemehmohammadi', '2025-07-31 13:35:16', '2025-07-31 13:36:04');
INSERT INTO `teammembers` VALUES ('3', '1', 'سینا احمدی', 'توسعه‌دهنده نرم‌افزار', 'سینا یک توسعه‌دهنده بااستعداد است که به طراحی و پیاده‌سازی نرم‌افزارهای کاربردی می‌پردازد.', '../image/team/member_1753956376_ff788045.jpg', 'sina@example.com', '09121234569', 'https://instagram.com/sinaahmadi', 'https://t.me/sinaahmadi', 'https://linkedin.com/in/sinaahmadi', '2025-07-31 13:35:16', '2025-07-31 13:36:16');
INSERT INTO `teammembers` VALUES ('4', '1', 'مریم اکبری', 'مدیر پروژه', 'مریم با بیش از 5 سال تجربه در مدیریت پروژه‌های فناوری، تیم را به سمت موفقیت هدایت می‌کند.', '../image/team/member_1753956386_1f7bcfde.jpg', 'maryam@example.com', '09121234570', 'https://instagram.com/maryamakbari', 'https://t.me/maryamakbari', 'https://linkedin.com/in/maryamakbari', '2025-07-31 13:35:16', '2025-07-31 13:36:26');
INSERT INTO `teammembers` VALUES ('5', '1', 'کامران نیکو', 'طراح UI/UX', 'کامران با خلاقیت و طراحی‌های جذاب، تجربه کاربری را بهبود می‌بخشد.', '../image/team/member_1753956394_617b0357.jpg', 'kamran@example.com', '09121234571', 'https://instagram.com/kamranneko', 'https://t.me/kamranneko', 'https://linkedin.com/in/kamranneko', '2025-07-31 13:35:16', '2025-07-31 13:36:34');
INSERT INTO `teammembers` VALUES ('6', '1', 'نیما سلیمانی', 'تحلیل‌گر داده', 'نیما مسئول تحلیل داده‌ها و ارائه گزارشات استراتژیک به تیم می‌باشد.', '../image/team/member_1753956406_266cf0dc.jpg', 'nima@example.com', '09121234572', 'https://instagram.com/nimasoleimani', 'https://t.me/nimasoleimani', 'https://linkedin.com/in/nimasoleimani', '2025-07-31 13:35:16', '2025-07-31 13:36:46');

--
-- Table structure for table `users`
--
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `avatar` varchar(255) DEFAULT 'static/img/default-avatar.svg',
  `role` enum('admin','user') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_activity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--
INSERT INTO `users` VALUES ('1', 'محمد احمدی', 'mohammad.ahmadi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456701', 'تهران، خیابان انقلاب، کوچه دانش، پلاک 12', '../image/avatars/default-avatar.jpg', 'user', '2023-01-15 10:30:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('2', 'فاطمه محمدی', 'fatemeh.mohammadi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456702', 'اصفهان، خیابان چهارباغ، پلاک 45', '../image/avatars/default-avatar.jpg', 'user', '2023-02-20 11:45:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('3', 'علی رضایی', 'ali.rezaei@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456703', 'مشهد، بلوار وکیل آباد، ساختمان نگین', '../image/avatars/default-avatar.jpg', 'user', '2023-03-05 09:15:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('4', 'زهرا حسینی', 'zahra.hosseini@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456704', 'شیراز، خیابان زند، مجتمع تجاری زیتون', '../image/avatars/default-avatar.jpg', 'user', '2023-04-10 14:20:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('5', 'رضا کریمی', 'reza.karimi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456705', 'تبریز، خیابان امام، برج سامان', '../image/avatars/default-avatar.jpg', 'user', '2023-05-12 16:30:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('6', 'نازنین نوروزی', 'nazanin.norouzi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456706', 'کرج، بلوار موذن، مجتمع پردیسان', '../image/avatars/default-avatar.jpg', 'user', '2023-06-18 08:45:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('7', 'امیرحسین فلاحی', 'amirhossein.falahi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456707', 'اهواز، کیانپارس، خیابان 12', '../image/avatars/default-avatar.jpg', 'user', '2023-07-22 13:10:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('8', 'سارا موسوی', 'sara.mousavi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456708', 'رشت، میدان شهرداری، ساختمان سپهر', '../image/avatars/default-avatar.jpg', 'user', '2023-08-30 17:25:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('9', 'حسین اکبری', 'hossein.akbari@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456709', 'ارومیه، خیابان امام، پاساژ آذربایجان', '../image/avatars/default-avatar.jpg', 'user', '2023-09-05 10:40:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('10', 'لیلا صادقی', 'leila.sadeghi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456710', 'قم، بلوار امین، کوچه 15', '../image/avatars/default-avatar.jpg', 'user', '2023-10-11 15:55:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('11', 'مهدی قربانی', 'mehdi.ghorbani@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456711', 'یزد، بلوار دانشجو، مجتمع مهر', '../image/avatars/default-avatar.jpg', 'user', '2023-11-15 12:05:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('12', 'مریم جعفری', 'maryam.jafari@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456712', 'کرمانشاه، میدان آزادی، برج نگین', '../image/avatars/default-avatar.jpg', 'user', '2023-12-20 09:30:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('13', 'پویا محمودی', 'pouya.mahmoudi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456713', 'همدان، بلوار بعثت، پلاک 23', '../image/avatars/default-avatar.jpg', 'user', '2024-01-25 14:45:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('14', 'نرگس امینی', 'narges.amini@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456714', 'بندرعباس، خیابان امام خمینی، مجتمع تجاری ستاره', '../image/avatars/default-avatar.jpg', 'user', '2024-02-10 11:20:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('15', 'امین طباطبایی', 'amin.tabatabaei@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456715', 'کرمان، بلوار جمهوری، ساختمان پاسارگاد', '../image/avatars/default-avatar.jpg', 'user', '2024-03-15 16:35:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('16', 'هانیه مرادی', 'haniyeh.moradi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456716', 'سنندج، خیابان پاسداران، کوچه 8', '../image/avatars/default-avatar.jpg', 'user', '2024-04-20 08:50:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('17', 'محسن یوسفی', 'mohsen.yousefi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456717', 'زاهدان، بلوار دانشگاه، پاساژ الماس', '../image/avatars/default-avatar.jpg', 'user', '2024-05-05 13:05:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('18', 'الهام نوری', 'elham.nouri@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456718', 'گرگان، خیابان ولیعصر، مجتمع آفتاب', '../image/avatars/default-avatar.jpg', 'user', '2024-06-10 17:20:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('19', 'سعید رحیمی', 'saeed.rahimi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456719', 'اراک، بلوار شهید بهشتی، ساختمان پرنس', '../image/avatars/default-avatar.jpg', 'user', '2024-07-15 10:35:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('20', 'نیلوفر شریفی', 'niloufar.sharifi@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '09123456720', 'ساری، میدان امام، پاساژ مروارید', '../image/avatars/default-avatar.jpg', 'user', '2024-08-20 14:50:00', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('21', 'Hoseiin Mirzaii', 'Mh.mirzaii1382@gmail.com', '$2y$10$VPs0op1FS4Ap.Cufft3SGuYC9Wr9teef59sObbHNnQ2ngH2tEeIE2', '09374340324', 'Hamedan', '../image/avatars/1751698446_IMG_20220802_053846_601.jpg', 'admin', '2025-07-05 10:23:41', '2025-07-31 16:54:06', '1753968246');
INSERT INTO `users` VALUES ('22', 'Ahmad', 'Ahmad@gmail.com', '$2y$10$2WwT.nXeQKui8iUFjXYyFuSh/jYybYJSzMRlsIsHlYhe7sN9xzdZO', '09345669879', 'تهران خیابان ازادی', '../image/avatars/1752227075_avatar-4.jpg', 'admin', '2025-07-06 20:21:43', '2025-07-28 11:56:31', '1753684420');
INSERT INTO `users` VALUES ('23', 'ali', 'Ali@gmail.com', '$2y$10$5LqM8kKbC1t0F2hDIXwwveUNWwbDJ0M07HV4oMLJzV1EEGSHU7SSG', '84656485', 'kjndsaskaj', '../image/default-avatar.jpg', 'user', '2025-07-18 11:14:33', '2025-07-28 11:56:31', NULL);
INSERT INTO `users` VALUES ('24', 'qqQ', 'QQ@gmail.com', '$2y$10$s5A1oYB8AjaN/NnmvQH55OwGS10cXeE/y7ao3vhJlhK0OlvBpFfCa', '98465135548', 'asdknsdkaklsd', '../image/default-avatar.svg', 'user', '2025-07-18 11:19:03', '2025-07-28 11:55:08', NULL);
INSERT INTO `users` VALUES ('25', 'Test', 'Test@gmail.com', '$2y$10$Y4b6lBu0DFctl7lXQPQVOur.JjrUyhz6chz9oz9MVr5A6czgHkNHS', '049856132', 'Test abad', '../image/default-avatar.svg', 'user', '2025-07-23 09:17:19', '2025-07-28 11:55:08', NULL);

--
-- Dumping triggers
--
DROP TRIGGER IF EXISTS `after_consultation_message_insert`;
DELIMITER //
CREATE TRIGGER `after_consultation_message_insert` AFTER INSERT ON `consultationmessages` FOR EACH ROW
BEGIN
    DECLARE consultation_topic VARCHAR(255);
    DECLARE receiver_id INT;
    
    SELECT topic INTO consultation_topic FROM Consultations WHERE id = NEW.consultation_id;
    
    -- تعیین دریافت کننده پیام
    IF NEW.sender_id = (SELECT user_id FROM Consultations WHERE id = NEW.consultation_id) THEN
        SET receiver_id = (SELECT advisor_id FROM Consultations WHERE id = NEW.consultation_id);
    ELSE
        SET receiver_id = (SELECT user_id FROM Consultations WHERE id = NEW.consultation_id);
    END IF;
    
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('new_message', 'پیام جدید در مشاوره', CONCAT('پیام جدید در مشاوره با موضوع ', consultation_topic), NEW.consultation_id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_consultation_insert`;
DELIMITER //
CREATE TRIGGER `after_consultation_insert` AFTER INSERT ON `consultations` FOR EACH ROW
BEGIN
    DECLARE user_name VARCHAR(255);
    DECLARE advisor_name VARCHAR(255);
    
    SELECT name INTO user_name FROM Users WHERE id = NEW.user_id;
    SELECT name INTO advisor_name FROM Users WHERE id = NEW.advisor_id;
    
    -- نوتیفیکیشن برای ادمین
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('new_consultation', 'درخواست مشاوره جدید', 
            CONCAT('درخواست مشاوره جدید از کاربر ', user_name, ' با موضوع ', NEW.topic), 
            NEW.id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_contact_message_insert`;
DELIMITER //
CREATE TRIGGER `after_contact_message_insert` AFTER INSERT ON `contactmessages` FOR EACH ROW
BEGIN
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('other', 'پیام جدید از تماس با ما', CONCAT('پیام جدید از ', NEW.name, ' با موضوع ', NEW.message), NEW.id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_discount_insert`;
DELIMITER //
CREATE TRIGGER `after_discount_insert` AFTER INSERT ON `discounts` FOR EACH ROW
BEGIN
    DECLARE product_name VARCHAR(255);
    
    SELECT name INTO product_name FROM Products WHERE id = NEW.product_id;
    
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('other', 'تخفیف جدید', CONCAT('تخفیف جدید برای محصول ', product_name, ' ثبت شد'), NEW.product_id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `before_discount_end_date_update`;
DELIMITER //
CREATE TRIGGER `before_discount_end_date_update` BEFORE UPDATE ON `discounts` FOR EACH ROW
BEGIN
    DECLARE product_name VARCHAR(255);
    
    IF NEW.end_date < DATE_ADD(NOW(), INTERVAL 3 DAY) AND OLD.end_date >= DATE_ADD(NOW(), INTERVAL 3 DAY) THEN
        SELECT name INTO product_name FROM Products WHERE id = NEW.product_id;
        
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('other', 'تخفیف در حال اتمام', 
                CONCAT('تخفیف محصول ', product_name, ' تا ', NEW.end_date, ' اعتبار دارد'), 
                NEW.product_id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_order_insert`;
DELIMITER //
CREATE TRIGGER `after_order_insert` AFTER INSERT ON `orders` FOR EACH ROW
BEGIN
    DECLARE user_name VARCHAR(255);
    
    SELECT name INTO user_name FROM Users WHERE id = NEW.user_id;
    
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('new_order', 'سفارش جدید', CONCAT('سفارش جدید از کاربر ', user_name, ' در سبد خرید' ' ثبت شد'), NEW.id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_order_status_update`;
DELIMITER //
CREATE TRIGGER `after_order_status_update` AFTER UPDATE ON `orders` FOR EACH ROW
BEGIN
    DECLARE user_name VARCHAR(255);
    
    IF OLD.status <> NEW.status THEN
        SELECT name INTO user_name FROM Users WHERE id = NEW.user_id;

        -- نوتیفیکیشن برای ادمین
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('order_status_change', 'تغییر وضعیت سفارش', 
                CONCAT('وضعیت سفارش شماره ', NEW.id, ' از ', OLD.status, ' به ', NEW.status, ' تغییر کرد'), 
                NEW.id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_payment_success`;
DELIMITER //
CREATE TRIGGER `after_payment_success` AFTER INSERT ON `payments` FOR EACH ROW
BEGIN
    DECLARE user_name VARCHAR(255);
    DECLARE order_total DECIMAL(12, 0);

    IF NEW.status = 'successful' THEN
        SELECT name INTO user_name FROM Users WHERE id = NEW.user_id;
        SELECT total_price INTO order_total FROM Orders WHERE id = NEW.order_id;

        -- نوتیفیکیشن برای ادمین
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('new_order', 'پرداخت موفق', CONCAT('پرداخت سفارش شماره ', NEW.order_id, ' توسط کاربر ', user_name, ' با مبلغ ', NEW.amount, ' انجام شد'), NEW.order_id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_product_insert`;
DELIMITER //
CREATE TRIGGER `after_product_insert` AFTER INSERT ON `products` FOR EACH ROW
BEGIN
    DECLARE category_name VARCHAR(255);
    
    SELECT name INTO category_name FROM Categories WHERE id = NEW.category_id;
    
    INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
    VALUES ('other', 'محصول جدید', CONCAT('محصول جدید با نام ', NEW.name, ' در دسته‌بندی ', category_name, ' اضافه شد'), NEW.id, FALSE, FALSE);
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `before_product_stock_update`;
DELIMITER //
CREATE TRIGGER `before_product_stock_update` BEFORE UPDATE ON `products` FOR EACH ROW
BEGIN
    IF NEW.stock < 5 AND NEW.stock > 0 AND OLD.stock >= 5 THEN
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('other', 'موجودی کم محصول', CONCAT('موجودی محصول ', NEW.name, ' در حال اتمام است. موجودی فعلی: ', NEW.stock), NEW.id, FALSE, FALSE);
    ELSEIF NEW.stock = 0 AND OLD.stock > 0 THEN
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('other', 'اتمام موجودی محصول', CONCAT('موجودی محصول ', NEW.name, ' به پایان رسید'), NEW.id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_product_view_insert`;
DELIMITER //
CREATE TRIGGER `after_product_view_insert` AFTER INSERT ON `productviews` FOR EACH ROW
BEGIN
    DECLARE total_views INT;
    DECLARE product_name VARCHAR(255);
    
    SELECT SUM(view_count) INTO total_views FROM ProductViews WHERE product_id = NEW.product_id;
    
    -- اگر بازدیدها از 1000 گذشت
    IF total_views % 1000 = 0 AND total_views > 0 THEN        
        SELECT name INTO product_name FROM Products WHERE id = NEW.product_id;
        
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('other', 'رکورد بازدید محصول', 
                CONCAT('محصول ', product_name, ' به ', total_views, ' بازدید رسید'), 
                NEW.product_id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_user_insert`;
DELIMITER //
CREATE TRIGGER `after_user_insert` AFTER INSERT ON `users` FOR EACH ROW
BEGIN
    IF NEW.role = 'user' THEN
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('new_user', 'کاربر جدید', CONCAT('کاربر جدید با نام ', NEW.name, ' ثبت نام کرد'), NEW.id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

DROP TRIGGER IF EXISTS `after_user_update`;
DELIMITER //
CREATE TRIGGER `after_user_update` AFTER UPDATE ON `users` FOR EACH ROW
BEGIN
    IF OLD.avatar <> NEW.avatar THEN
        INSERT INTO Notifications (type, title, message, related_id, is_read, is_dismissed)
        VALUES ('other', 'تغییر تصویر پروفایل', CONCAT('کاربر ', NEW.name, ' تصویر پروفایل خود را تغییر داد'), NEW.id, FALSE, FALSE);
    END IF;
END//
DELIMITER ;

--
-- Dumping routines
--
-- No procedures found

-- No functions found

--
-- Dumping events
--
-- No events found

SET FOREIGN_KEY_CHECKS=1;
COMMIT;
